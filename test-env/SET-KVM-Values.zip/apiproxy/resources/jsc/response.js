 	var payoutId = context.getVariable('private.ClientID');
 res={
     "Hello":"Rakesh",
     "key":payoutId
 };
 
 

 
context.setVariable('request.content', JSON.stringify(res))