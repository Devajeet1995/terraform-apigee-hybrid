   var response="";
var x=context.getVariable('requestTriggerError');
if(x!="true"){
response = context.getVariable('errorMessage').replace(/"/g, '\'');
}
var responseStatusCode;
var newresponse={};

var timestamp = context.getVariable("system.timestamp");
var currDate = new Date(timestamp);
var dateTimeIsoString = currDate.toISOString();
// split by dot
var currDateTime = dateTimeIsoString.replace(/Z+$/, '');
var timeZoneOffset = currDate.getTimezoneOffset();
var positiveOffset = Math.abs(timeZoneOffset)
var timeOffsetInHours = -(timeZoneOffset/60)
var minZone = (positiveOffset - Math.floor(timeOffsetInHours) * 60)
var symbolOffset = timeZoneOffset > 0 ? '-' : '+' ;
var hourOffset = Math.floor(timeOffsetInHours) < 10 ? 0 : '';
var minOffset = minZone < 10 ? 0 : '';
var tzd = symbolOffset + hourOffset + Math.floor(timeOffsetInHours) + ":" + minOffset + minZone
var dateTZDformat = currDateTime + tzd;


if(context.getVariable('requestTriggerError')=="true"){
        if(context.getVariable('request.header.Content-Length')>102400){
        newresponse["timeOfFailure"]= dateTZDformat;
        newresponse["failureType"]="Request entity too large";
        newresponse["shortMsg"]="Large payload size";  
        newresponse["longMsg"]="Size of payload is bigger than 100kb";  
        responseStatusCode=413;
            
        }else{newresponse["timeOfFailure"]= dateTZDformat;
        newresponse["failureType"]="Unsupported media type";
        newresponse["shortMsg"]="Missing or wrong Content-Type";  
        newresponse["longMsg"]="Content-Type header is missing or invalid";  
        responseStatusCode=415;
        }
}

context.setVariable("error.status.code", responseStatusCode);
context.setVariable('error.content', JSON.stringify(newresponse));