 var target_url = context.getVariable('target.url');
var proxy=context.getVariable('proxy.pathsuffix');

var keyId=context.getVariable('private.keyId');
var sharedSecret=context.getVariable('private.sharedSecret');

print(keyId);
print(sharedSecret);



print(proxy);

if(proxy == "/sendpayout"){
    context.setVariable('target.url', target_url+'/visapayouts/v1/sendpayout');
}else if(proxy == "/validatepayout"){
     context.setVariable('target.url', target_url+'/visapayouts/v1/validatepayout');
}else{
     context.setVariable('target.url', target_url+'/visapayouts/v1'+proxy);
}

