var keyId=context.getVariable('private.keyId');
print("KeyID - "+keyId);

var sharedSecret=context.getVariable('private.sharedSecret');
print("VisaDirect SharedSecret - "+sharedSecret);

var validation_sharedKey=context.getVariable('private.validation_sharedKey');
print("ValidateAPI SharedSecret - "+validation_sharedKey);
