var response = context.getVariable('error.content');
var responseStatusCode;
var newresponse={};

var timestamp = context.getVariable("system.timestamp");
var currDate = new Date(timestamp);
var dateTimeIsoString = currDate.toISOString();
// split by dot
var currDateTime = dateTimeIsoString.replace(/Z+$/, '');
var timeZoneOffset = currDate.getTimezoneOffset();
var positiveOffset = Math.abs(timeZoneOffset)
var timeOffsetInHours = -(timeZoneOffset/60)
var minZone = (positiveOffset - Math.floor(timeOffsetInHours) * 60)
var symbolOffset = timeZoneOffset > 0 ? '-' : '+' ;
var hourOffset = Math.floor(timeOffsetInHours) < 10 ? 0 : '';
var minOffset = minZone < 10 ? 0 : '';
var tzd = symbolOffset + hourOffset + Math.floor(timeOffsetInHours) + ":" + minOffset + minZone
var dateTZDformat = currDateTime + tzd;

newresponse["timeOfFailure"]= dateTZDformat;

if(response.includes("platform app: merchant_id not supplied")){
   
   newresponse["failureType"]="Bad Request";
   newresponse["shortMsg"]="merchant_id header is not supplied";  
   newresponse["longMsg"]="Your app is registered as a platform app. A required http header merchant_id should be supplied";  

}

else if(response.includes("standard app: merchant_id not allowed")){
   
   newresponse["failureType"]="Bad Request";
   newresponse["shortMsg"]="invalid http header merchant_id";  
   newresponse["longMsg"]="merchant_id http header should not be supplied with this request";  

}

else if(response.includes("platform app: merchant_id not available in kvm")){
   
   newresponse["failureType"]="Forbidden";
   newresponse["shortMsg"]="merchant_id not allowed";  
   newresponse["longMsg"]="You are not allowed to operate on behalf of this merchant";  

}

else if(response.includes("standard app: merchant not configured in kvm")){
   
   newresponse["failureType"]="Forbidden";
   newresponse["shortMsg"]="Not Configured";  
   newresponse["longMsg"]="You are not configured to operate on behalf of this merchant. Please contact Earthport support.";  

}


else if(response.includes("SyntaxError:")){
newresponse["timeOfFailure"]= dateTZDformat;
newresponse["failureType"]="validation";
newresponse["shortMsg"]="Invalid Inputs";  
newresponse["longMsg"]="Invalid Inputs";  
}

// context.setVariable("error.status.code", responseStatusCode);
context.setVariable('error.content', JSON.stringify(newresponse));