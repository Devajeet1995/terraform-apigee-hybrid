 // encodePassword.js
// ------------------------------------------------------------------
//
// Description goes here....
//
// created: Mon Dec 18 12:39:29 2017
// last saved: <2017-December-18 12:45:47>

var resolveVariableReference = (function (globalScope){
      'use strict';

      var variableNameRe = "[^ \t\n\"',/\\\\{}]+?"; // non-greedy capture
      var varPrefixRe = '{';
      var varSuffixRe = '}';
      var variableRegex = new RegExp( varPrefixRe + '(' + variableNameRe + ')' + varSuffixRe);

      function resolveVariableReference(s) {
        var match = variableRegex.exec(s);
        if (match){
          var variableName = match[1];
          var value = context.getVariable(variableName);
          if (value && value !== '') {
            s = s.replace('{' + variableName + '}', value);
          }
        }
        return s;
      }
      return resolveVariableReference;
    }(this));

function getCreated() {
  var time = (new Date()).toISOString(); // eg, 2011-10-05T14:48:07.000Z
  var re1 = new RegExp('\\.[0-9]{3}');
  return time.replace(re1, '');  // eg, 2011-10-05T14:48:07
}

var password = resolveVariableReference(properties.password);
var nonce = context.getVariable('messageid');
var created = getCreated();
var sha1 = crypto.getSHA1();
sha1.update(nonce + created + password);
var hashed_token = sha1.digest64();

context.setVariable('encoded_password', hashed_token);
context.setVariable('nonce', nonce);
context.setVariable('created', created);
