 var merchant_id=context.getVariable('request.header.merchant_id');
 var company=context.getVariable('CompanyName');
 var app=context.getVariable('AppName');
 var isPlatform=context.getVariable('isPlatform');
 var client;
 var triggerError=false;
 var errorMessage='';
 var target_visa_host_key=null; // for visa qa20

 if(company===null || company===''){
 client = 'earthport.target';  // A generic target for developer apps  
// client = context.getVariable('apigee.developer.email'); //developer specific target for developer apps    
 }
 else{
     if(isPlatform === "1") {
        if(merchant_id===null || merchant_id==='') {
                triggerError=true;
                errorMessage="platform app: merchant_id not supplied"
        }
        else{
                client= company+'.'+app+'.'+merchant_id
        }

     }
     else{
        if(merchant_id===null || merchant_id==='') {
                client= company+'.'+app;
                target_visa_host_key=client+'.host'; // for visa  qa20 env

        }
        else{
                triggerError=true;
                errorMessage="standard app: merchant_id not allowed"
        }
     }
 }
 
 var username_key=client+'.username'
 var password_key=client+'.password'
 var target_port_key=client+'.port'
 var target_host_key='earthport.target.host'
 context.setVariable('wss-username-key',username_key);
 context.setVariable('wss-password-key',password_key);
 context.setVariable('target-port-key',target_port_key);
 context.setVariable('target-host-key',target_host_key);
 context.setVariable('target-visa-host-key',target_visa_host_key);  // for visa qa20
 context.setVariable('triggerError',triggerError);
 context.setVariable('errorMessage',errorMessage);
 
 