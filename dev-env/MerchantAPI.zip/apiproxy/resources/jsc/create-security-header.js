 var username = context.getVariable('private.wss-username');
 var password = context.getVariable('private.wss-password');
  var company=context.getVariable('CompanyName');
 var env= context.getVariable('environment.name');


 var target_port = context.getVariable('private.target-port');
 var target_host = context.getVariable('private.target-host');
 var isPlatform = context.getVariable('isPlatform');
 var triggerError = false;
 var errorMessage = '';


 if (target_host === null || username === null || password === null) {
     triggerError = true;
     if (isPlatform === "1") {
         errorMessage = 'platform app: merchant_id not available in kvm'
     } else {
         errorMessage = 'standard app: merchant not configured in kvm'
     }
 }


 if (target_port === null || target_port === '') {
     target_port = 10301;
 }

if(company === "VISADirect" && ( env === "qa" || env === "dev" )){
            var target_url = 'https://' + target_host + ':' + target_port + '/ep-web-ws-router/services/MerchantAPI'

}else{
    //  var target_url = 'https://' + target_host + ':' + target_port + '/MerchantAPI'
     var target_url="https://apigee-aks.nalphatech.co.in/v1/visa/merchant";
}



 //var username='EarthportPaymentTest';
 //var password='Passw0rd';

 //var security_header="&lt;wsse:Security soapenv:mustUnderstand=\"1\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\"&gt;&lt;wsse:UsernameToken wsu:Id=\"UsernameToken-D97A8787D9B2CC265415247398463387\"&gt;&lt;wsse:Username&gt;"+username+"&lt;/wsse:Username&gt;&lt;wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\"&gt;"+password+"&lt;/wsse:Password&gt;&lt;wsse:Nonce EncodingType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary\"&gt;u+Wak96L8mrEjWW9z16dmQ==&lt;/wsse:Nonce&gt;&lt;wsu:Created&gt;2018-04-26T10:50:46.338Z&lt;/wsu:Created&gt;&lt;/wsse:UsernameToken&gt;&lt;/wsse:Security&gt";
 var security_header = "<wsse:Security xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" soapenv:mustUnderstand=\"1\"><wsse:UsernameToken wsu:Id=\"UsernameToken-D97A8787D9B2CC265415247398463387\"><wsse:Username>" + username + "</wsse:Username><wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">" + password + "</wsse:Password><wsse:Nonce EncodingType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary\">u+Wak96L8mrEjWW9z16dmQ==</wsse:Nonce><wsu:Created>2018-04-26T10:50:46.338Z</wsu:Created></wsse:UsernameToken></wsse:Security>"


//  var target_url = 'https://' + "test.earthport.com" + ':' + target_port + '/MerchantAPI'

 context.setVariable('ws-security-header', security_header);
 context.setVariable('target-url', target_url);
 context.setVariable('triggerError', triggerError);
 context.setVariable('errorMessage', errorMessage);