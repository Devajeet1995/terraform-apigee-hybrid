 
var response=JSON.parse(context.getVariable('soapresponse.body'));


   //function to check that string is float or not and return true or false
function floatingPoint(str) {
    var pattern = /^[-+]?[0-9]+\.[0-9]+$/;
    return pattern.test(str);
}

// this function is used to check that float is parseable or not   
 function isFloatParsable(str) {
    var pattern = /^[-+]?[0-9]{1,13}\.[0-9]{1,2}$/;
    return pattern.test(str);
}

 function floatStartWithZero(str) {
    var pattern = /^[-+]?(0)[0-9]+\.[0-9]+$/;
    return pattern.test(str);
}

 function floatStartWithZeroDot(str) {
    var pattern = /^[-+]?(0)\.[0-9]+$/;
    return pattern.test(str);
}

// to check the string is in number or not
 function numbers(str) {
       var pattern = /^[-+]?[0-9]*$/;
       return pattern.test(str);
  }
  
  function numberStartWithZero(str){
      var pattern =/^[-+]?(0)[0-9]*$/;
      return pattern.test(str);
  }

// convesion of data types is perform in this function 
function format(json_string) {
    return JSON.parse(json_string, function (key, value) {
            if(Array.isArray(value)){
    
                     if(floatingPoint(value))
                     {
                          if(floatStartWithZeroDot(value)){
                              return parseFloat(value);   
                          }
                          else if(floatStartWithZero(value)){
                              return value;
                          }else{
                              
                              if(isFloatParsable(value)){
                                return parseFloat(value);
                              }
                              else{
                                  return value;
                              }
                          }
                     }
                     else if(numbers(value))
                     {
                         if(numberStartWithZero(value)){
                            return  value.length===1 ? parseInt(value) : value;   
                         }
                         else{
                             
                             if(Number.isSafeInteger(Number(value))){
                                 return  parseInt(value);
                             }else{
                                 return value;
                             }
                           
                         }
    
                     }
                     return value;
            }
            else {
    
                 if(floatingPoint(value))
                 {   
                     if(floatStartWithZeroDot(value)){
                      return parseFloat(value);   
                     }
                     else if(floatStartWithZero(value)){
                         return value;
                     }else{
                          if(isFloatParsable(value)){
                                return parseFloat(value);
                              }
                              else{
                                  return value;
                              }
                     }
    
                 }
                 else if(numbers(value))
                 {
                         if(numberStartWithZero(value)){
                            return  value.length === 1 ? parseInt(value) : value;   
                         }
                         else{
                             
                             if(Number.isSafeInteger(Number(value))){
                                 return  parseInt(value);
                             }else{
                                 return value;
                             }
                         }
    
                 }
                 return value ;
         } 
    
    });
}


modifiedRes=JSON.parse(JSON.stringify(format(JSON.stringify(response))));


context.setVariable('soapresponse.body', JSON.stringify(modifiedRes));


//var identifier = response.submitDocumentResponse.submitDocumentReturn.getTransactionDetailResponse.transactionDetailMappings.transactionDetailMapping.transactionDetail.payerIdentity.payerIndividualIdentity.identificationList.identification.identificationNumber;
//print(response);