 var managedMerchantName=context.getVariable('accesstoken.managedMerchantName');
 context.setVariable('managedMerchantName',managedMerchantName);