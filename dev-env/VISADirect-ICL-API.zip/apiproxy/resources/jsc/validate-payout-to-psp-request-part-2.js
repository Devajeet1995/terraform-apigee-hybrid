/**
   1- userDetails ( senderDetail )
**/
try
{

    var request = parse(context.getVariable('private.originalRequest').replace(/:\s*(\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d+)\s*([,\}])/g, ':"$1"$2'));
    var earthportrequest = parse(context.getVariable('private.earthportRequest'));
    var merchantID=context.getVariable('private.validation_merchantIdentity');
    var sender_hashValue = "";
    var id = {}; 
         
    //#region userDetails  
    if ('senderDetail' in request) {

        var dataCount = 0;
        var fullName = false; // for unstructured 

        if ("fullName" in request.senderDetail) {  fullName = true;   }
   
        earthportrequest.userDetails = {};
        earthportrequest.userDetails.identity = {};
            
        if ((request.senderDetail.type == 'I') && !(fullName)) {
            earthportrequest.userDetails.identity.identityType = "payerIndividual";

            //#region  identificationList         
            if (Array.isArray(request.senderDetail.identificationList)) {
                var totalId = request.senderDetail.identificationList.length;
                if (totalId > 0) {
  
                    earthportrequest.userDetails.identity.identificationList = [];
                    var j=0; // if array contain null value
  
                    for (var i = 0; i < totalId; i++) {
  
                      if(request.senderDetail.identificationList[i] !== undefined){                    
                        if(request.senderDetail.identificationList[i].hasOwnProperty("idType") || request.senderDetail.identificationList[i].hasOwnProperty("idNumber") ||  request.senderDetail.identificationList[i].hasOwnProperty("idIssueCountry")){
     
                            if(Object.keys(idTypeExceptional).indexOf(request.senderDetail.identificationList[i].idType) === -1 ){
                      
                              if(request.senderDetail.identificationList[i].hasOwnProperty("idType") || request.senderDetail.identificationList[i].hasOwnProperty("idNumber") ||  request.senderDetail.identificationList[i].hasOwnProperty("idIssueCountry")){
                                  earthportrequest.userDetails.identity.identificationList[j] = {};
                              }
      
                      
                              if (Object.keys(idType).indexOf(request.senderDetail.identificationList[i].idType) > -1) {
                                  if(request.senderDetail.identificationList[i].hasOwnProperty("idType") ){
                                    earthportrequest.userDetails.identity.identificationList[j].identificationNumberType=idType[request.senderDetail.identificationList[i].idType]
                                  }
                              }else{
                                  if(request.senderDetail.identificationList[i].hasOwnProperty("idType") ){
                                    earthportrequest.userDetails.identity.identificationList[j].identificationNumberType = request.senderDetail.identificationList[i].idType;
                                  }  
                              }
                      
                          
                              if(request.senderDetail.identificationList[i].hasOwnProperty("idNumber")) {                                
                                earthportrequest.userDetails.identity.identificationList[j].identificationNumber = request.senderDetail.identificationList[i].idNumber;
                              }
      
                              if( request.senderDetail.identificationList[i].hasOwnProperty("idIssueCountry")){                                
                                  earthportrequest.userDetails.identity.identificationList[j].identificationCountry =  getCountryCode(request.senderDetail.identificationList[i].idIssueCountry);
                              } 
                      
                            }
                          }
                        j++;  
                      }
                    }      
                }
            }

            //#endregion
            
            if("firstName" in request.senderDetail && "lastName" in request.senderDetail){
                earthportrequest.userDetails.identity.identityName = request.senderDetail.firstName+" "+request.senderDetail.lastName;
            }

            earthportrequest.userDetails.identity.active = true;
            earthportrequest.userDetails.identity.givenNames = request.senderDetail.firstName;
            earthportrequest.userDetails.identity.familyName = request.senderDetail.lastName;
            earthportrequest.userDetails.identity.mobileTelephoneNumber = request.senderDetail.contactNumber;
            
            
            if('countryOfBirth' in request.senderDetail && 'dateOfBirth' in request.senderDetail){
                earthportrequest.userDetails.identity.birthInformation = {};
                if('cityOfBirth' in request.senderDetail){
                  earthportrequest.userDetails.identity.birthInformation.city = request.senderDetail.cityOfBirth;            
                }
                earthportrequest.userDetails.identity.birthInformation["country.name"] = getCountryCode(request.senderDetail.countryOfBirth);         
                earthportrequest.userDetails.identity.birthInformation.date = request.senderDetail.dateOfBirth;
            }

        }
        else if (request.senderDetail.type == 'C') {
            earthportrequest.userDetails.identity.identityType = "payerCompany";
            
            if (fullName) {
                earthportrequest.userDetails.identity.identityName =  request.senderDetail.fullName;
                earthportrequest.userDetails.identity.companyName = request.senderDetail.fullName;

            }else{
                earthportrequest.userDetails.identity.identityName =  request.senderDetail.companyName;
                earthportrequest.userDetails.identity.companyName = request.senderDetail.companyName;
            }

            earthportrequest.userDetails.identity.active = true;

            if (Array.isArray(request.senderDetail.identificationList)) {
              var totalId = request.senderDetail.identificationList.length;
              if (totalId > 0) {

                if(request.senderDetail.identificationList[0] !== undefined){

                    if(request.senderDetail.identificationList[0].hasOwnProperty("idType")){
                        if(request.senderDetail.identificationList[0].idType === "L" ){
                            if(request.senderDetail.identificationList[0].hasOwnProperty("idNumber") ||  request.senderDetail.identificationList[0].hasOwnProperty("idIssueCountry")){
                                earthportrequest.userDetails.identity.companyRegistration = {};
                              }
          
                            if(request.senderDetail.identificationList[0].hasOwnProperty("idNumber")) {                                
                                earthportrequest.userDetails.identity.companyRegistration.companyRegistrationNumber = request.senderDetail.identificationList[0].idNumber; 
                              }
                            if(request.senderDetail.identificationList[0].hasOwnProperty("idIssueCountry")){                                
                                earthportrequest.userDetails.identity.companyRegistration["companyRegistrationCountry.name"] = getCountryCode(request.senderDetail.identificationList[0].idIssueCountry);
                              }       
                        }
                    }            
                }
              }
            }
            
        }else if((request.senderDetail.type === undefined) || (request.senderDetail.type == "I" && fullName)){

            var identityData = 0;
            earthportrequest.userDetails.identity.identityType = "payerUnstructured";

            earthportrequest.userDetails.identity.identityData=[];

            if("type" in request.senderDetail){
             id = {
                "key": "IdentityType",
                "value": request.senderDetail.type
                };
                earthportrequest.userDetails.identity.identityData[identityData++] = id;
            }

            if('fullName' in request.senderDetail){
                id = {
                   "key": "Name",
                   "value": request.senderDetail.fullName
                   };
                   earthportrequest.userDetails.identity.identityData[identityData++] = id;
                }
   
               if('address' in request.senderDetail){
                 if('addressLine1' in request.senderDetail.address){
                   id = {
                      "key": "AddressLine1",
                      "value": request.senderDetail.address.addressLine1
                      };
                   earthportrequest.userDetails.identity.identityData[identityData++] = id;
                  }
      
                  if('addressLine2' in request.senderDetail.address){
                   id = {
                      "key": "AddressLine2",
                      "value": request.senderDetail.address.addressLine2
                      };
                   earthportrequest.userDetails.identity.identityData[identityData++] = id;
                  }
      
                  if('addressLine3' in request.senderDetail.address){
                   id = {
                      "key": "AddressLine3",
                      "value": request.senderDetail.address.addressLine3
                      };
                   earthportrequest.userDetails.identity.identityData[identityData++] = id;
                  }
      
                  if('country' in request.senderDetail.address){
                   id = {
                      "key": "Country",
                      "value": getCountryCode(request.senderDetail.address.country)
                      };
                   earthportrequest.userDetails.identity.identityData[identityData++] = id;
                  }
      
                  if('city' in request.senderDetail.address){
                   id = {
                      "key": "City",
                      "value": request.senderDetail.address.city
                      };
                   earthportrequest.userDetails.identity.identityData[identityData++] = id;
                  }
      
                  if('province' in request.senderDetail.address){
                   id = {
                      "key": "Province",
                      "value": request.senderDetail.address.province
                      };
                   earthportrequest.userDetails.identity.identityData[identityData++] = id;
                  }
      
                  if('postalCode' in request.senderDetail.address){
                   id = {
                      "key": "Postcode",
                      "value": request.senderDetail.address.postalCode
                      };
                   earthportrequest.userDetails.identity.identityData[identityData++] = id;
                  }   
               }
            
               if('countryOfBirth' in request.senderDetail || 'dateOfBirth' in request.senderDetail || 'cityOfBirth' in request.senderDetail ){
   
                if(!("additionalData" in earthportrequest.userDetails.identity)){
                    earthportrequest.userDetails.identity.additionalData = [];
                 }
   
                 if('countryOfBirth' in request.senderDetail){
                  id = {
                     "propertyType": "ISO_COUNTRY_CODE_OF_BIRTH",
                     "propertyValue": getCountryCode(request.senderDetail.countryOfBirth)
                     };
                     earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                    }
   
                 if('cityOfBirth' in request.senderDetail){
                  id = {
                     "propertyType": "PLACE_OF_BIRTH",
                     "propertyValue": request.senderDetail.cityOfBirth
                     };
                     earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                    }
   
                 if('dateOfBirth' in request.senderDetail){
                  id = {
                     "propertyType": "DATE_OF_BIRTH",
                     "propertyValue": request.senderDetail.dateOfBirth
                     };
                     earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                    }
               }
   
               if (Array.isArray(request.senderDetail.identificationList)) {
                 var totalId = request.senderDetail.identificationList.length;
                 
                 if(!("additionalData" in earthportrequest.userDetails.identity)){
                    earthportrequest.userDetails.identity.additionalData = [];
                 }
   
                 if (totalId > 0) {
   
                     for (var i = 0; i < totalId; i++) {
   
                         if (request.senderDetail.identificationList[i] !== undefined) {
                             if (request.senderDetail.identificationList[i].hasOwnProperty("idType") || request.senderDetail.identificationList[i].hasOwnProperty("idNumber") || request.senderDetail.identificationList[i].hasOwnProperty("idIssueCountry")) {
                                 if ((Object.keys(idTypeExceptional).indexOf(request.senderDetail.identificationList[i].idType) === -1)) {
                                     if (Object.keys(idTypeAdditional).indexOf(request.senderDetail.identificationList[i].idType) > -1) {
                                         if (request.senderDetail.identificationList[i].hasOwnProperty("idType")) {
                                          id = {
                                             "propertyType": idTypeAdditional[request.senderDetail.identificationList[i].idType],
                                             "propertyValue": request.senderDetail.identificationList[i].idNumber
                                           }
                                           earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                                        }
   
                                     } else {
                                         if (request.senderDetail.identificationList[i].hasOwnProperty("idType")) {
                                            id = {
                                                 "propertyType": request.senderDetail.identificationList[i].idType,
                                                 "propertyValue": request.senderDetail.identificationList[i].idNumber
                                               }
                                               earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                                            }
                                     }
   
                                     if (request.senderDetail.identificationList[i].hasOwnProperty("idIssueCountry")) {
                                        id = {
                                             "propertyType": "ISO_COUNTRY_CODE_ID_ISSUER",
                                             "propertyValue": getCountryCode(request.senderDetail.identificationList[i].idIssueCountry)
                                           }
                                           earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
    
                                     }
                                 }
                             }
                         }
                     }
                 }
               }

        }

        //for idType I , C & unstructured as well 
       
        //Additional data -- identificationList
            if (Array.isArray(request.senderDetail.identificationList)) {
              var totalId = request.senderDetail.identificationList.length;
              if (totalId > 0) {

                if(!("additionalData" in earthportrequest.userDetails.identity)){
                    earthportrequest.userDetails.identity.additionalData = [];
                 }

                  for (var i = 0; i < totalId; i++) {
                    if(request.senderDetail.identificationList[i] !== undefined){                    
                      if ((request.senderDetail.identificationList[i].hasOwnProperty("idType") && request.senderDetail.identificationList[i].hasOwnProperty("idNumber")) || request.senderDetail.identificationList[i].hasOwnProperty("idName")) {
                        if(Object.keys(idTypeExceptional).indexOf(request.senderDetail.identificationList[i].idType) > -1 ){
                          //logic for idType F - ForeginID
                          if(request.senderDetail.identificationList[i].idType == "F" && request.senderDetail.identificationList[i].hasOwnProperty("idNumber")){

                            if(request.senderDetail.identificationList[i].hasOwnProperty("idName")){
                              id = {
                                "propertyType": request.senderDetail.identificationList[i].idName,
                                "propertyValue": request.senderDetail.identificationList[i].idNumber
                              };
                            }else{
                              id = {
                                "propertyType": "FOREIGN_ID",
                                "propertyValue": request.senderDetail.identificationList[i].idNumber
                              };
                            }
                            earthportrequest.userDetails.identity.additionalData[dataCount++] = id;

                          }else if(request.senderDetail.identificationList[i].hasOwnProperty("idNumber") && request.senderDetail.identificationList[i].hasOwnProperty("idName")){
                            id = {
                              "propertyType": request.senderDetail.identificationList[i].idName,
                              "propertyValue": request.senderDetail.identificationList[i].idNumber
                            };
                            earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                          }
                        }
                      }
                    }
                  }
              }
            }

            if (Array.isArray(request.senderDetail.additionalData)) {
              var totalId = request.senderDetail.additionalData.length;
              if (totalId > 0) {
              
                  if("additionalData" in earthportrequest.userDetails.identity){
                      for (var i = 0; i < totalId; i++) {
                        if(request.senderDetail.additionalData[i] !== undefined){
                          if(Object.keys(skip_additionalDataName).indexOf(request.senderDetail.additionalData[i].name) == -1 ){
                            id = {
                              "propertyType": request.senderDetail.additionalData[i].name,
                              "propertyValue": request.senderDetail.additionalData[i].value
                              };
                              earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                          }
                        }
                        
                      }
                    }else{
                      earthportrequest.userDetails.identity.additionalData = [];

                      for (var i = 0; i < totalId; i++) {
                        if(request.senderDetail.additionalData[i] !== undefined){
                          if(Object.keys(skip_additionalDataName).indexOf(request.senderDetail.additionalData[i].name) == -1 ){
                            id = {
                              "propertyType": request.senderDetail.additionalData[i].name,
                              "propertyValue": request.senderDetail.additionalData[i].value
                              };
                              earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                          }
                        }
                        
                      }            
                }
            }

            }

            //for the contact Number
            if("contactNumber" in request.senderDetail){
                
                    if(dataCount>0){
                        id = {
                        "propertyType": "MOBILE_PHONE_NUMBER",
                        "propertyValue": request.senderDetail.contactNumber
                        };
                        earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                    }
                    else{

                        earthportrequest.userDetails.identity.additionalData = [];

                        id = {
                            "propertyType": "MOBILE_PHONE_NUMBER",
                            "propertyValue": request.senderDetail.contactNumber
                            };
                    earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                    }
            }

              //for the contactEmail
            if("contactEmail" in request.senderDetail){

                    if(dataCount>0){
                        id = {
                            "propertyType": "EMAIL_ADDRESS",
                            "propertyValue": request.senderDetail.contactEmail
                        };
                        earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                        }
                    else{

                        earthportrequest.userDetails.identity.additionalData = [];
                        id = {
                          "propertyType": "EMAIL_ADDRESS",
                          "propertyValue": request.senderDetail.contactEmail
                        };
                        earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                    }
            }

           //for the contactEmail
           if("senderReferenceNumber" in request.senderDetail){

           if(dataCount>0){
                 id = {
                    "propertyType": "PAYER_ACCOUNT_NUMBER",
                    "propertyValue": request.senderDetail.senderReferenceNumber
                 };
                 earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
                 }
           else{

                 earthportrequest.userDetails.identity.additionalData = [];
                 id = {
                    "propertyType": "PAYER_ACCOUNT_NUMBER",
                    "propertyValue": request.senderDetail.senderReferenceNumber
                 };
                 earthportrequest.userDetails.identity.additionalData[dataCount++] = id;
             }
         }

            //Address
            if ('address' in request.senderDetail && earthportrequest.userDetails.identity.identityType !== "payerUnstructured") {
              earthportrequest.userDetails.identity.address = {};
              earthportrequest.userDetails.identity.address.addressLine1 = request.senderDetail.address.addressLine1;
              earthportrequest.userDetails.identity.address.addressLine2 = request.senderDetail.address.addressLine2;
              earthportrequest.userDetails.identity.address.addressLine3 = request.senderDetail.address.addressLine3;
              earthportrequest.userDetails.identity.address.city = request.senderDetail.address.city;
              earthportrequest.userDetails.identity.address.province = request.senderDetail.address.province;
              earthportrequest.userDetails.identity.address.postCode = request.senderDetail.address.postalCode;
              earthportrequest.userDetails.identity.address["country.name"] = getCountryCode(request.senderDetail.address.country);
            }
        

        //Hashing
        if("identity" in earthportrequest.userDetails){
          getPayerDetails(JSON.stringify(earthportrequest.userDetails.identity));
        }

        earthportrequest.userDetails.accountCurrency = "any";

        if(sender_hashValue !== ""){
          if("userDetails" in earthportrequest){
              earthportrequest.userDetails.merchantUserID ="_hashed_token";
          }
        }else{
           if("userDetails" in earthportrequest){
            earthportrequest.userDetails.merchantUserID=undefined;
          }
        }

        if(merchantID !== ""){
          earthportrequest.userDetails.merchantID=merchantID;
        }   
       
    }
      
    //#endregion




    earthportrequest=parse(JSON.stringify(earthportrequest));

    context.setVariable('private.earthportRequest', JSON.stringify(earthportrequest));
    context.setVariable('private.source',"validate_EP_Request");

} catch(err) {  
     context.setVariable("triggerScriptError", true);
     context.setVariable("triggerScriptErrorMessage", err.message);
     throw err.message;
    }