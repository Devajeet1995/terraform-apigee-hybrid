/**
    1- Contain payoutDetails 
    2- Set request.content variable with earthportrequest
**/

try
{
  var request=parse(context.getVariable('private.originalRequest').replace(/:\s*(\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d+)\s*([,\}])/g, ':"$1"$2'));
  var earthportrequest=parse(context.getVariable('private.earthportRequest'));

  var dataCount = 0; // for additionalData Increment

 //Writing entire payload to Key-Value pairs  
 var kvArray = [] ;
 


 kvPayoutDetails({"key":null,"value":request});


 //#region payoutDetails
 earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"] = [];
 var kvp_total = 0;// for key value increment
 
 if ('transactionDetail' in request) {
     if ('purposeOfPayment' in request.transactionDetail) {
         var id = {
             "ns8:key": "PURPOSE_OF_PAYMENT",
             "ns8:value": request.transactionDetail.purposeOfPayment
         };
         earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total] = id;
         kvp_total++;
     }
     if ('settlementCurrencyCode' in request.transactionDetail) {
         var id = {
             "ns8:key": "FUNDING_CURRENCY",
             "ns8:value": getCurrencyCode(request.transactionDetail.settlementCurrencyCode)
         };
         earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total] = id;
         kvp_total++;
     }
 }

 if ('originatorDetail' in request) {
     if ('bankCountryCode' in request.originatorDetail) {
         var id = {
             "ns8:key": "ORIGINATOR_DETAIL_ACQUIRER_COUNTRY_CODE",
             "ns8:value": getCountryCode(request.originatorDetail.bankCountryCode)
         };
         earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total] = id;
         kvp_total++;
     }
     if ('address' in request.originatorDetail) {
         if ('country' in request.originatorDetail.address) {
             var id = {
                 "ns8:key": "ORIGINATOR_DETAIL_MERCHANT_ADDRESS_COUNTRY",
                 "ns8:value": getCountryCode(request.originatorDetail.address.country)
             };
             earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total] = id;
             kvp_total++;
         }
     }
     
       //RAPI - 57   
     if('intermediaryCountryCode' in request.originatorDetail){
          var id = {
            "ns8:key": "ORIGINATOR_DETAIL_INTERMEDIARY_COUNTRY_CODE",
            "ns8:value": getCountryCode(request.originatorDetail.intermediaryCountryCode)
        };
        earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total] = id;
        kvp_total++; 
     }
     
     //RAPI - 105 && RAPI 109
     if('bankId' in request.originatorDetail && 'bankBIC' in request.originatorDetail){
       var bankId = request.originatorDetail.bankId;
         if(bankId === 487035 && request.originatorDetail.originatorBIC === undefined){
          var id = {
            "ns8:key": "ORIGINATORDETAIL.ORIGINATORBIC",
            "ns8:value": request.originatorDetail.bankBIC
          };
          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total++] = id;
         }
         
         if(bankId === 493853 && request.originatorDetail.originatorId === 'MGIS2A000000001'  && request.originatorDetail.originatorBIC === undefined){
          var id = {
            "ns8:key": "ORIGINATORDETAIL.ORIGINATORBIC",
            "ns8:value": 'MGRMUS44'
          };
          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total++] = id;
         }

         if(bankId === 320027 && request.originatorDetail.originatorId === 'CAIDCode77765'  && request.originatorDetail.originatorBIC === undefined){
          var id = {
            "ns8:key": "ORIGINATORDETAIL.ORIGINATORBIC",
            "ns8:value": request.originatorDetail.bankBIC
          };
          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total++] = id;
        }

         if(bankId === 426708 && request.originatorDetail.originatorBIC === undefined){
          var id = {
            "ns8:key": "ORIGINATORDETAIL.ORIGINATORBIC",
            "ns8:value": request.originatorDetail.bankBIC
          };
          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total++] = id;
        }

     }else if ('bankId' in request.originatorDetail ){
      var bankId = request.originatorDetail.bankId;
       if(bankId === 493853 && request.originatorDetail.originatorId === 'MGIS2A000000001'  && request.originatorDetail.originatorBIC === undefined){
          var id = {
            "ns8:key": "ORIGINATORDETAIL.ORIGINATORBIC",
            "ns8:value": 'MGRMUS44'
          };
          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total++] = id;
        }
       
     }     
 }


 if ('recipientDetail' in request) {  
   if (Array.isArray(request.recipientDetail.additionalData)) {
     var totalId = request.recipientDetail.additionalData.length;
     if (totalId > 0) {
          for (var i = 0; i < totalId; i++) {
             if(request.recipientDetail.additionalData[i] !== undefined){
               if(request.recipientDetail.additionalData[i].name == "KID"){
                   var id = {
                     "ns8:key": "KID",
                     "ns8:value": request.recipientDetail.additionalData[i].value
                 };
                 earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total] = id;
                 kvp_total++;
               }                  
             }                
           }            
       }
    }   
     
   if (Array.isArray(request.recipientDetail.identificationList)) {
     var totalId = request.recipientDetail.identificationList.length;
     if (totalId > 0) {
       for (var i = 0; i < totalId; i++) {
         if(request.recipientDetail.identificationList[i] !== undefined){
           if (request.recipientDetail.identificationList[i].hasOwnProperty("idType") && request.recipientDetail.identificationList[i].hasOwnProperty("idNumber") && request.recipientDetail.identificationList[i].hasOwnProperty("idName")) {
             if(request.recipientDetail.identificationList[i].idType == "T"  && Object.keys(skip_idName).indexOf(request.recipientDetail.identificationList[i].idName) > -1){
                 var id = {
                   "ns8:key": skip_idName[request.recipientDetail.identificationList[i].idName],
                   "ns8:value": request.recipientDetail.identificationList[i].idNumber
                 };
               earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total] = id;
               kvp_total++;

             }
           }
           } 
       }            
     }
   }
 
 }

 if ('senderDetail' in request) {  
   if (Array.isArray(request.senderDetail.additionalData)) {
     var totalId = request.senderDetail.additionalData.length;
     if (totalId > 0) {
          for (var i = 0; i < totalId; i++) {
             if(request.senderDetail.additionalData[i] !== undefined){
               if(Object.keys(skip_additionalDataName).indexOf(request.senderDetail.additionalData[i].name) > -1 ){
                 var id = {
                     "ns8:key": skip_additionalDataName[request.senderDetail.additionalData[i].name],
                     "ns8:value": request.senderDetail.additionalData[i].value
                 };
                 earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total] = id;
                 kvp_total++;
               }                  
             }                
           }            
       }
     }    
 }
 
 for ( var i = 0; i < kvArray.length; i++)
 {    
     if (String(kvArray[i].key).length <= 50 && String(kvArray[i].value).length <= 100) {
       var  id={"ns8:key": kvArray[i].key.toUpperCase() , "ns8:value" : kvArray[i].value};
       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutDetails"][kvp_total]=id;
       kvp_total++;
     }   
 }

 //#endregion

 earthportrequest=parse(JSON.stringify(earthportrequest));

 context.setVariable('request.content', JSON.stringify(earthportrequest));
 context.setVariable('private.source',"earthportRequest");

} catch(err) {  
     context.setVariable("triggerScriptError", true);
     context.setVariable("triggerScriptErrorMessage", err.message);
     throw err.message;
    }
