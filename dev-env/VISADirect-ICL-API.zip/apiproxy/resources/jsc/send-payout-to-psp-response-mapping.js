try{
    var request = JSON.parse(context.getVariable('private.originalRequest'));
    var response = JSON.parse(context.getVariable('response.content').replace(/:\s*(\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d+)\s*([,\}])/g, ':"$1"$2'));

    var newresponse = {};
    if ('createOrUpdateUserAddBeneficiaryBankAccountAndPayoutResponse' in response.submitDocumentResponse.submitDocumentReturn) {
        if ('originatorDetail' in request) {
            if ('bankId' in request.originatorDetail || 'originatorId' in request.originatorDetail) {
                newresponse.originatorDetail = {};
            }
            if ('bankId' in request.originatorDetail) {
                newresponse.originatorDetail.bankId = request.originatorDetail.bankId;
            }
            if ('originatorId' in request.originatorDetail) {
                newresponse.originatorDetail.originatorId = request.originatorDetail.originatorId;
            }
        }
        if('serviceProviderDetail' in request){
            if ('routingId' in request.serviceProviderDetail) {
                newresponse.serviceProviderDetail = {};
                newresponse.serviceProviderDetail.routingId = request.serviceProviderDetail.routingId;
            }
        }
        if('transactionDetail' in request){
            if ('retrievalReferenceNumber' in request.transactionDetail || 'systemTraceAuditNumber' in request.transactionDetail || 'amount' in request.transactionDetail || 'transactionCurrencyCode' in request.transactionDetail || 'transmissionDateTime' in request.transactionDetail || 'destinationAmount' in request.transactionDetail || 'destinationCurrencyCode' in request.transactionDetail || 'payoutSpeed' in request.transactionDetail || 'expectedSettlementDate' in response.submitDocumentResponse.submitDocumentReturn.createOrUpdateUserAddBeneficiaryBankAccountAndPayoutResponse || 'paymentID' in response.submitDocumentResponse.submitDocumentReturn.createOrUpdateUserAddBeneficiaryBankAccountAndPayoutResponse) {
            newresponse.transactionDetail = {};
                if ('retrievalReferenceNumber' in request.transactionDetail) {
                newresponse.transactionDetail.retrievalReferenceNumber = request.transactionDetail.retrievalReferenceNumber;
                }
                if ('systemTraceAuditNumber' in request.transactionDetail) {
                newresponse.transactionDetail.systemTraceAuditNumber = request.transactionDetail.systemTraceAuditNumber;
                }
                if ('amount' in request.transactionDetail) {
                    newresponse.transactionDetail.transactionAmount = request.transactionDetail.amount;
                }
                if ('transactionCurrencyCode' in request.transactionDetail) {
                    newresponse.transactionDetail.transactionCurrencyCode = request.transactionDetail.transactionCurrencyCode;
                }
                if ('transmissionDateTime' in request.transactionDetail) {
                    newresponse.transactionDetail.transmissionDateTime = request.transactionDetail.transmissionDateTime;
                }
                if ('destinationAmount' in request.transactionDetail) {
                    newresponse.transactionDetail.destinationAmount = request.transactionDetail.destinationAmount;
                }
                if ('destinationCurrencyCode' in request.transactionDetail) {
                    newresponse.transactionDetail.destinationCurrencyCode = request.transactionDetail.destinationCurrencyCode;
                }
                if ('payoutSpeed' in request.transactionDetail) {
                    newresponse.transactionDetail.payoutSpeed = request.transactionDetail.payoutSpeed;
                }
                if ('expectedSettlementDate' in response.submitDocumentResponse.submitDocumentReturn.createOrUpdateUserAddBeneficiaryBankAccountAndPayoutResponse) {
                    newresponse.transactionDetail.expectedPostingDate = response.submitDocumentResponse.submitDocumentReturn.createOrUpdateUserAddBeneficiaryBankAccountAndPayoutResponse.expectedSettlementDate.replace("Z","");
                }
                
                if ('paymentID' in response.submitDocumentResponse.submitDocumentReturn.createOrUpdateUserAddBeneficiaryBankAccountAndPayoutResponse) {
                    newresponse.transactionDetail.paymentTrackingId = response.submitDocumentResponse.submitDocumentReturn.createOrUpdateUserAddBeneficiaryBankAccountAndPayoutResponse.paymentID;
                }
            }
        }
        responseStatusCode = 200;
        context.setVariable("response.status.code", responseStatusCode);
        context.setVariable('response.content', JSON.stringify(newresponse));
        context.setVariable('private.source',"visaResponse");
    
    }
    
    if ('errors' in response.submitDocumentResponse.submitDocumentReturn) {
        newresponse = response.submitDocumentResponse.submitDocumentReturn.errors;
        responseStatusCode = 400;
        context.setVariable("triggerServerError", true);
        context.setVariable("triggerServerErrorMessage", JSON.stringify(newresponse));
        context.setVariable("response.status.code", responseStatusCode);
        context.setVariable('response.content', JSON.stringify(newresponse));
     }
} catch(err) {  
     context.setVariable("triggerScriptError", true);
     context.setVariable("triggerScriptErrorMessage", err.message);
     throw err.message;
    }