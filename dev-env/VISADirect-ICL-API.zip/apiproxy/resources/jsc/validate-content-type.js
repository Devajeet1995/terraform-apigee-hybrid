var verb=context.getVariable('request.verb');  
var pathsuffix = context.getVariable('proxy.pathsuffix');
var content_type=context.getVariable('request.header.Content-Type');

var cancelPayout_prefix = pathsuffix.substr(0,8);

if(pathsuffix=== "/sendpayout" || pathsuffix=== "/validatepayout" || cancelPayout_prefix === "/payouts"){
       if(content_type != "application/jose"){
        context.setVariable('trigger_contentType',true);
        throw "Invalid Content Type";
      } 
}


