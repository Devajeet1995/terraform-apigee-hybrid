try {
  var response = JSON.parse(context.getVariable('response.content'));
  
  var responseStatusCode = 200;
  var newresponse = {};

  if ('cancellationRequestResponse' in response.submitDocumentResponse.submitDocumentReturn) {

      newresponse.transactionDetail={};

      if ('status' in response.submitDocumentResponse.submitDocumentReturn.cancellationRequestResponse) {
          if (response.submitDocumentResponse.submitDocumentReturn.cancellationRequestResponse.status === "Cancelled") {
              newresponse.transactionDetail.status = "CANCELLED";
              newresponse.transactionDetail.description = "CANCELLED";

          } else if (response.submitDocumentResponse.submitDocumentReturn.cancellationRequestResponse.status === "PendingCancellation") {
              newresponse.transactionDetail.status = "PENDING_CANCELLATION";
              newresponse.transactionDetail.description = "PENDING_CANCELLATION";
          }
      }

    
  } else if ("errors" in response.submitDocumentResponse.submitDocumentReturn) {
            newresponse.transactionDetail={};
            newresponse = response.submitDocumentResponse.submitDocumentReturn.errors;
            responseStatusCode = 400;
            context.setVariable("triggerServerError", true);
            context.setVariable("triggerServerErrorMessage", JSON.stringify(newresponse));
  }

  context.setVariable('private.source',"visaResponse");
  context.setVariable('response.content', JSON.stringify(newresponse));
  context.setVariable("response.status.code", responseStatusCode);
  
} catch(err) {  
   context.setVariable("triggerScriptError", true);
   context.setVariable("triggerScriptErrorMessage", err.message);
   throw err.message;
  }