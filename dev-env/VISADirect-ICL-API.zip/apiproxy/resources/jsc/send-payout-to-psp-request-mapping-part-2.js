/**
    1- Contain beneficiaryBankAccount (recipientDetail )
    2- merchantTransactionReference value 
    3- payoutRequestAmount
    4- beneficiaryAmountInformation
    5- serviceLevel & beneficiaryStatementNarrative
    6- payerType
**/

try {
    var request = parse(context.getVariable('private.originalRequest').replace(/:\s*(\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d+)\s*([,\}])/g, ':"$1"$2'));
    var earthportrequest = parse(context.getVariable('private.earthportRequest'));

    var dataCount = 0; // for additionalData Increment
    var fullName = false; // for unstructured 



    //#region beneficiaryBankAccount  
    if ('recipientDetail' in request) {

      var dataCount = 0; // for additionalData increment

      if ("fullName" in request.recipientDetail) {
          fullName = true;
       }

      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"] = {};
      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"] = {};

      if ((request.recipientDetail.type == 'I') && !(fullName)) {
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"] = {};
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:name"] = {};
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:name"]["ns3:givenNames"] = request.recipientDetail.firstName;
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:name"]["ns3:familyName"] = request.recipientDetail.lastName;

              if ('address' in request.recipientDetail) {
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:address"] = {};
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:address"]["ns3:addressLine1"] = request.recipientDetail.address.addressLine1;
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:address"]["ns3:addressLine2"] = request.recipientDetail.address.addressLine2;
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:address"]["ns3:addressLine3"] = request.recipientDetail.address.addressLine3;
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:address"]["ns3:city"] = request.recipientDetail.address.city;
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:address"]["ns3:province"] = request.recipientDetail.address.province;
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:address"]["ns3:postcode"] = request.recipientDetail.address.postalCode;
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:address"]["ns3:country"] = getCountryCode(request.recipientDetail.address.country);
              }

              if (Array.isArray(request.recipientDetail.identificationList)) {
                  var totalId = request.recipientDetail.identificationList.length;

                  if (totalId > 0) {

                      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:identificationList"] = {};
                      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:identificationList"]["ns3:identification"] = [];

                      var j = 0; // if array contain null value

                      for (var i = 0; i < totalId; i++) {

                          if (request.recipientDetail.identificationList[i] !== undefined) {

                              if (request.recipientDetail.identificationList[i].hasOwnProperty("idType") || request.recipientDetail.identificationList[i].hasOwnProperty("idNumber") || request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")) {
                                if ((Object.keys(idTypeExceptional).indexOf(request.recipientDetail.identificationList[i].idType) === -1) && skipIdentificationList(request.recipientDetail.identificationList[i].idType,getCountryCode(request.recipientDetail.bank.countryCode))) {

                                      if (request.recipientDetail.identificationList[i].hasOwnProperty("idType") || request.recipientDetail.identificationList[i].hasOwnProperty("idNumber") || request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")) {
                                          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j] = {};
                                      }

                                      if (Object.keys(idType).indexOf(request.recipientDetail.identificationList[i].idType) > -1) {

                                          if (request.recipientDetail.identificationList[i].hasOwnProperty("idType")) {
                                              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j]["ns3:idType"] = idType[request.recipientDetail.identificationList[i].idType];
                                          }

                                      } else {
                                          if (request.recipientDetail.identificationList[i].hasOwnProperty("idType")) {
                                              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j]["ns3:idType"] = request.recipientDetail.identificationList[i].idType;
                                          }
                                      }


                                      if (request.recipientDetail.identificationList[i].hasOwnProperty("idNumber")) {
                                          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j]["ns3:identificationNumber"] = request.recipientDetail.identificationList[i].idNumber;
                                      }

                                      if (request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")) {
                                          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j]["ns3:identificationCountry"] = getCountryCode(request.recipientDetail.identificationList[i].idIssueCountry);
                                      } else {
                                          if ("bank" in request.recipientDetail) {
                                              if ("countryCode" in request.recipientDetail.bank) {
                                                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j]["ns3:identificationCountry"] = getCountryCode(request.recipientDetail.bank.countryCode);
                                              }
                                          }
                                      }
                                      j++;
                                  }
                              }
                          }
                      }

                      //delete if additional data is null
                      if (earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:identificationList"]["ns3:identification"].length === 0) {
                          delete earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:identificationList"];
                      }

                  }
              }

              if ('countryOfBirth' in request.recipientDetail && 'dateOfBirth' in request.recipientDetail) {
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:birthInformation"] = {};
                  if ('cityOfBirth' in request.recipientDetail) {
                      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:birthInformation"]["ns3:cityOfBirth"] = request.recipientDetail.cityOfBirth;
                  }
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:birthInformation"]["ns3:countryOfBirth"] = getCountryCode(request.recipientDetail.countryOfBirth);
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryIndividualIdentity"]["ns3:birthInformation"]["ns3:dateOfBirth"] = request.recipientDetail.dateOfBirth;
              }

       }else if (request.recipientDetail.type == 'C') {

          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"] = {};

          if (fullName) {
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:legalEntityName"] = request.recipientDetail.fullName;
          } else if ("companyName" in request.recipientDetail) {
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:legalEntityName"] = request.recipientDetail.companyName;
          }

          if (Array.isArray(request.recipientDetail.identificationList)) {
              var totalId = request.recipientDetail.identificationList.length;
              if (totalId > 0) {

                  if (request.recipientDetail.identificationList[0] !== undefined) {

                      if (request.recipientDetail.identificationList[0].hasOwnProperty("idType")) {

                          if (request.recipientDetail.identificationList[0].idType === "L") {

                              if (request.recipientDetail.identificationList[0].hasOwnProperty("idType") || request.recipientDetail.identificationList[0].hasOwnProperty("idNumber") || request.recipientDetail.identificationList[0].hasOwnProperty("idIssueCountry")) {
                                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:legalEntityRegistration"] = {};
                              }

                              if (request.recipientDetail.identificationList[0].hasOwnProperty("idNumber")) {
                                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:legalEntityRegistration"]["ns3:legalEntityRegistrationNumber"] = request.recipientDetail.identificationList[0].idNumber;
                              }

                              if (request.recipientDetail.identificationList[0].hasOwnProperty("idIssueCountry")) {
                                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:legalEntityRegistration"]["ns3:legalEntityRegistrationCountry"] = getCountryCode(request.recipientDetail.identificationList[0].idIssueCountry);
                              } else {
                                  if ("bank" in request.recipientDetail) {
                                      if ("countryCode" in request.recipientDetail.bank && request.recipientDetail.identificationList[0].hasOwnProperty("idNumber")) {
                                          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:legalEntityRegistration"]["ns3:legalEntityRegistrationCountry"] = getCountryCode(request.recipientDetail.bank.countryCode);
                                      }
                                  }
                              }

                              //delete if legalEntityRegistration object is empty
                              if (Object.keys(earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:legalEntityRegistration"]) == 0) {
                                  delete earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:legalEntityRegistration"];
                              }
                          }
                      }
                  }
              }
          }

          if ('address' in request.recipientDetail) {
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:address"] = {};
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:address"]["ns3:addressLine1"] = request.recipientDetail.address.addressLine1;
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:address"]["ns3:addressLine2"] = request.recipientDetail.address.addressLine2;
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:address"]["ns3:addressLine3"] = request.recipientDetail.address.addressLine3;
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:address"]["ns3:city"] = request.recipientDetail.address.city;
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:address"]["ns3:province"] = request.recipientDetail.address.province;
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:address"]["ns3:postcode"] = request.recipientDetail.address.postalCode;
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryLegalEntityIdentity"]["ns3:address"]["ns3:country"] = getCountryCode(request.recipientDetail.address.country);
          }

        }else if((request.recipientDetail.type === undefined) || (request.recipientDetail.type == "I" && fullName)){
            //#region RAPI-95 Code
      
            var UID = 0; // increment for unstructuredIdentity array
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"] = {};
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"]["ns3:unstructuredIdentityData"] = [];
           
            if("type" in request.recipientDetail)
            {
                var id = {
                    "ns3:unstructuredIdentityDataKey": "IdentityType",
                    "ns3:unstructuredIdentityDataValue": request.recipientDetail.type
                }
                earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"]["ns3:unstructuredIdentityData"][UID++] = id;   
            }
           
            if ("fullName" in request.recipientDetail) {
                var id = {
                    "ns3:unstructuredIdentityDataKey": "Name",
                    "ns3:unstructuredIdentityDataValue": request.recipientDetail.fullName
                }
                earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"]["ns3:unstructuredIdentityData"][UID++] = id;
            }
            if ("address" in request.recipientDetail) {
                if ("addressLine1" in request.recipientDetail.address) {
                    var id = {
                        "ns3:unstructuredIdentityDataKey": "AddressLine1",
                        "ns3:unstructuredIdentityDataValue": request.recipientDetail.address.addressLine1
                    }
                    earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"]["ns3:unstructuredIdentityData"][UID++] = id;
                }
                if ("addressLine2" in request.recipientDetail.address) {
                    var id = {
                        "ns3:unstructuredIdentityDataKey": "AddressLine2",
                        "ns3:unstructuredIdentityDataValue": request.recipientDetail.address.addressLine2
                    }
                    earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"]["ns3:unstructuredIdentityData"][UID++] = id;
                }
                if ("addressLine3" in request.recipientDetail.address) {
                    var id = {
                        "ns3:unstructuredIdentityDataKey": "AddressLine3",
                        "ns3:unstructuredIdentityDataValue": request.recipientDetail.address.addressLine3
                    }
                    earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"]["ns3:unstructuredIdentityData"][UID++] = id;
                }
                if ("city" in request.recipientDetail.address) {
                    var id = {
                        "ns3:unstructuredIdentityDataKey": "City",
                        "ns3:unstructuredIdentityDataValue": request.recipientDetail.address.city
                    }
                    earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"]["ns3:unstructuredIdentityData"][UID++] = id;
                }
                if ("province" in request.recipientDetail.address) {
                    var id = {
                        "ns3:unstructuredIdentityDataKey": "Province",
                        "ns3:unstructuredIdentityDataValue": request.recipientDetail.address.province
                    }
                    earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"]["ns3:unstructuredIdentityData"][UID++] = id;
                }
                if ("postalCode" in request.recipientDetail.address) {
                    var id = {
                        "ns3:unstructuredIdentityDataKey": "Postcode",
                        "ns3:unstructuredIdentityDataValue": request.recipientDetail.address.postalCode
                    }
                    earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"]["ns3:unstructuredIdentityData"][UID++] = id;
                }
                if ("country" in request.recipientDetail.address) {
                    var id = {
                        "ns3:unstructuredIdentityDataKey": "Country",
                        "ns3:unstructuredIdentityDataValue": getCountryCode(request.recipientDetail.address.country)
                    }
                    earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:beneficiaryUnstructuredIdentity"]["ns3:unstructuredIdentityData"][UID++] = id;
                }
            }
       }

      //#endregion

      //#region  AdditionalDataList 

      // 1) identificationList
      if (Array.isArray(request.recipientDetail.identificationList)) {
          var totalId = request.recipientDetail.identificationList.length;
          if (totalId > 0) {
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"] = {};
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"] = [];

              for (var i = 0; i < totalId; i++) {

                  if (request.recipientDetail.identificationList[i] !== undefined) {
                      if ((request.recipientDetail.identificationList[i].hasOwnProperty("idType") && request.recipientDetail.identificationList[i].hasOwnProperty("idNumber")) || request.recipientDetail.identificationList[i].hasOwnProperty("idName")) {
                          if (Object.keys(idTypeExceptional).indexOf(request.recipientDetail.identificationList[i].idType) > -1 && Object.keys(skip_idName).indexOf(request.recipientDetail.identificationList[i].idName) == -1) {
                              if (request.recipientDetail.identificationList[i].idType == "F" && request.recipientDetail.identificationList[i].hasOwnProperty("idNumber")) {
                                  if (request.recipientDetail.identificationList[i].hasOwnProperty("idName")) {
                                      var id = {
                                          "ns3:additionalDataKey": request.recipientDetail.identificationList[i].idName,
                                          "ns3:additionalDataValue": request.recipientDetail.identificationList[i].idNumber
                                      };
                                  } else {
                                      var id = {
                                          "ns3:additionalDataKey": "FOREIGN_ID",
                                          "ns3:additionalDataValue": request.recipientDetail.identificationList[i].idNumber
                                      };
                                  }
                                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                                  dataCount++;

                              } else if (request.recipientDetail.identificationList[i].hasOwnProperty("idNumber") && request.recipientDetail.identificationList[i].hasOwnProperty("idName")) {
                                  var id = {
                                      "ns3:additionalDataKey": request.recipientDetail.identificationList[i].idName,
                                      "ns3:additionalDataValue": request.recipientDetail.identificationList[i].idNumber
                                  };
                                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                                  dataCount++;
                              }
                          }
                      }

                      //country specific logic for costa rica 
                      if (request.recipientDetail.identificationList[i].hasOwnProperty("idType") && request.recipientDetail.identificationList[i].hasOwnProperty("idNumber")) {
                          if (request.recipientDetail.identificationList[i].idType == "N") {
                              if (request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")) {
                                  if (getCountryCode(request.recipientDetail.identificationList[i].idIssueCountry) == "CR") {
                                      var id = {
                                          "ns3:additionalDataKey": "NATIONAL_ID_CARD",
                                          "ns3:additionalDataValue": request.recipientDetail.identificationList[i].idNumber
                                      };
                                      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                                      dataCount++;
                                  }

                              } else if ("bank" in request.recipientDetail) {
                                  if ("countryCode" in request.recipientDetail.bank) {
                                      if (getCountryCode(request.recipientDetail.bank.countryCode) == "CR") {
                                          var id = {
                                              "ns3:additionalDataKey": "NATIONAL_ID_CARD",
                                              "ns3:additionalDataValue": request.recipientDetail.identificationList[i].idNumber
                                          };
                                          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                                          dataCount++;
                                      }
                                  }
                              }
                          }
                      }
                  }
              }

              //delete if additional data is null
              if (earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"].length === 0) {
                  delete earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"];
              }
          }
      }

      //#region AdditionalDataList RAPI-95 Code
      if ((request.recipientDetail.type === undefined) || (request.recipientDetail.type == "I" && fullName )) {

          if (!("ns3:additionalDataList" in earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"])) {
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"] = {};
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"] = [];
          }

          if("dateOfBirth" in request.recipientDetail)
          {
              var id = {
                  "ns3:additionalDataKey": "DATE_OF_BIRTH",
                  "ns3:additionalDataValue": request.recipientDetail.dateOfBirth
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount++] = id;
          }

          if("countryOfBirth" in request.recipientDetail)
          {
              var id = {
                  "ns3:additionalDataKey": "ISO_COUNTRY_CODE_OF_BIRTH",
                  "ns3:additionalDataValue": getCountryCode(request.recipientDetail.countryOfBirth)
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount++] = id;
          }

          if("cityOfBirth" in request.recipientDetail)
          {
              var id = {
                  "ns3:additionalDataKey": "PLACE_OF_BIRTH",
                  "ns3:additionalDataValue": request.recipientDetail.cityOfBirth
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount++] = id;
          }

          if (Array.isArray(request.recipientDetail.identificationList)) {
              var totalId = request.recipientDetail.identificationList.length;

              if (totalId > 0) {

                  for (var i = 0; i < totalId; i++) {

                      if (request.recipientDetail.identificationList[i] !== undefined) {

                          if (request.recipientDetail.identificationList[i].hasOwnProperty("idType") || request.recipientDetail.identificationList[i].hasOwnProperty("idNumber") || request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")) {
                              if (Object.keys(idTypeExceptional).indexOf(request.recipientDetail.identificationList[i].idType) === -1 && skipIdentificationList(request.recipientDetail.identificationList[i].idType,getCountryCode(request.recipientDetail.bank.countryCode))) {
                                  if (Object.keys(idType).indexOf(request.recipientDetail.identificationList[i].idType) > -1) {
                                      if (request.recipientDetail.identificationList[i].hasOwnProperty("idType")) {
                                         var id = {
                                          "ns3:additionalDataKey": idTypeAdditional[request.recipientDetail.identificationList[i].idType],
                                          "ns3:additionalDataValue": request.recipientDetail.identificationList[i].idNumber
                                         }
                                         earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                                         dataCount++;
                                      }

                                  } else {
                                      if (request.recipientDetail.identificationList[i].hasOwnProperty("idType")) {
                                          var id = {
                                              "ns3:additionalDataKey": request.recipientDetail.identificationList[i].idType,
                                              "ns3:additionalDataValue": request.recipientDetail.identificationList[i].idNumber
                                             }
                                             earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                                             dataCount++;
                                      }
                                  }

                                  if (request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")) {
                                      var id = {
                                          "ns3:additionalDataKey": "ISO_COUNTRY_CODE_ID_ISSUER",
                                          "ns3:additionalDataValue": getCountryCode(request.recipientDetail.identificationList[i].idIssueCountry)
                                         }
                                         earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                                         dataCount++;
                                  } else {
                                      if ("bank" in request.recipientDetail) {
                                          if ("countryCode" in request.recipientDetail.bank) {
                                              var id = {
                                                  "ns3:additionalDataKey": "ISO_COUNTRY_CODE_ID_ISSUER",
                                                  "ns3:additionalDataValue": getCountryCode(request.recipientDetail.bank.countryCode)
                                                 }
                                                 earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                                                 dataCount++;
                                          }
                                      }
                                  }
                              }
                          }
                      }
                  }
              }
          }
      }
      //#endregion

      // 2) additionalData
      if (Array.isArray(request.recipientDetail.additionalData)) {
          var totalId = request.recipientDetail.additionalData.length;
          if (totalId > 0) {

              if (!("ns3:additionalDataList" in earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"])) {
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"] = {};
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"] = [];
              }

              for (var i = 0; i < totalId; i++) {
                  if (request.recipientDetail.additionalData[i] !== undefined) {

                      if (Object.keys(skip_additionalDataName).indexOf(request.recipientDetail.additionalData[i].name) == -1) {
                          var id = {
                              "ns3:additionalDataKey": (Object.keys(additionalDataName).indexOf(request.recipientDetail.additionalData[i].name) > -1) ? additionalDataName[request.recipientDetail.additionalData[i].name] : request.recipientDetail.additionalData[i].name,
                              "ns3:additionalDataValue": request.recipientDetail.additionalData[i].value
                          };
                          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                          dataCount++;
                      }
                  }
              }

          }
      }

      // 3) contact Number
      if ("contactNumber" in request.recipientDetail) {
          var contactFlag = false;

          if (!("ns3:additionalDataList" in earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"])) {
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"] = {};
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"] = [];
          }

          if ('bank' in request.recipientDetail) {
              if ("countryCode" in request.recipientDetail.bank) {
                  if (getCountryCode(request.recipientDetail.bank.countryCode) == "TR") {
                      var id = {
                          "ns3:additionalDataKey": "INTERNATIONAL_PHONE_NUMBER",
                          "ns3:additionalDataValue": request.recipientDetail.contactNumber
                      };
                      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                      dataCount++;
                      contactFlag = true;
                  }
              }

          }

          if (contactFlag == false) {
              var id = {
                  "ns3:additionalDataKey": "MOBILE_PHONE_NUMBER",
                  "ns3:additionalDataValue": request.recipientDetail.contactNumber
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
              dataCount++;
          }
      }

      // 4) contactEmail
      if ("contactEmail" in request.recipientDetail) {


          if (!("ns3:additionalDataList" in earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"])) {
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"] = {};
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"] = [];
          }

          var id = {
              "ns3:additionalDataKey": "EMAIL_ADDRESS",
              "ns3:additionalDataValue": request.recipientDetail.contactEmail
          };

          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:beneficiaryIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
          dataCount++;

      }

      //#endregion

      //#region basic bank Info
      if ('bank' in request.recipientDetail) {

          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:description"] = request.recipientDetail.bank.accountName;

          if ("countryCode" in request.recipientDetail.bank) {
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:countryCode"] = getCountryCode(request.recipientDetail.bank.countryCode);
          }

          if ("currencyCode" in request.recipientDetail.bank) {
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:currencyCode"] = getCurrencyCode(request.recipientDetail.bank.currencyCode);
          }

      }
      //#endregion

      //#region bankAccountDetails
      if ('bank' in request.recipientDetail) {

          // only for Czech Republic option 1
          if (getCountryCode(request.recipientDetail.bank.countryCode) == "CZ") {
              if ("accountNumber" in request.recipientDetail.bank) {
                  if (/^[0-9a-zA-z]*-[0-9a-zA-z]*[\/][0-9a-zA-z]*$/.test(request.recipientDetail.bank.accountNumber)) {
                      accountInfo = request.recipientDetail.bank.accountNumber.split("-");
                      request.recipientDetail.bank.accountNumberPrefix = accountInfo[0];
                      accountInfo = accountInfo[1].split("/");
                      request.recipientDetail.bank.accountNumberType = "DEFAULT";
                      request.recipientDetail.bank.accountNumber = accountInfo[0];
                      request.recipientDetail.bank.bankCodeType = "DEFAULT";
                      request.recipientDetail.bank.bankCode = accountInfo[1];
                  }
              }
          }

          //country specific logic - RAPI 98 
          if (getCountryCode(request.recipientDetail.bank.countryCode) == "NZ") {

              if ('accountNumber' in request.recipientDetail.bank) {
                  var accountNumber_Value = request.recipientDetail.bank.accountNumber;
                  var accountNumber_length = request.recipientDetail.bank.accountNumber.length;

                  if (accountNumber_length > 7 && request.recipientDetail.bank.accountNumberSuffix === undefined) {
                      var accountNumberSuffix = accountNumber_Value.substring(7);
                      accountNumber_Value = accountNumber_Value.substring(0, 7);
                      request.recipientDetail.bank.accountNumber = accountNumber_Value;
                      request.recipientDetail.bank.accountNumberSuffix = accountNumberSuffix;
                  }
              }
          }


          var i = 0;

          earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"] = [];

          if ('bankName' in request.recipientDetail.bank) {
              id = {
                  "ns4:key": "bankName",
                  "ns4:value": request.recipientDetail.bank.bankName
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
              i++;
          }

          if ('accountName' in request.recipientDetail.bank) {
              id = {
                  "ns4:key": "accountName",
                  "ns4:value": request.recipientDetail.bank.accountName
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
              i++;
          }


          if ("accountNumberSuffix" in request.recipientDetail.bank) {
              id = {
                  "ns4:key": "accountNumberSuffix",
                  "ns4:value": request.recipientDetail.bank.accountNumberSuffix
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
              i++;
          }

          if ("accountNumber" in request.recipientDetail.bank && 'accountNumberType' in request.recipientDetail.bank) {
              if ((Object.keys(accountNumber).indexOf(request.recipientDetail.bank.accountNumberType) > -1)) {
                  id = {
                      "ns4:key": accountNumber[request.recipientDetail.bank.accountNumberType],
                      "ns4:value": request.recipientDetail.bank.accountNumber
                  };
              } else {
                  id = {
                      "ns4:key": request.recipientDetail.bank.accountNumberType,
                      "ns4:value": request.recipientDetail.bank.accountNumber
                  };
              }
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
              i++;
          } else if ("accountNumber" in request.recipientDetail.bank) {
              id = {
                  "ns4:key": "accountNumber",
                  "ns4:value": request.recipientDetail.bank.accountNumber
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
              i++;
          }

          if ("accountNumberPrefix" in request.recipientDetail.bank) {

              id = {
                  "ns4:key": "accountNumberPrefix",
                  "ns4:value": request.recipientDetail.bank.accountNumberPrefix
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
              i++;

          }

          if ('accountType' in request.recipientDetail.bank) {
              if ("countryCode" in request.recipientDetail.bank) {
                  id = {
                      "ns4:key": "accountType",
                      "ns4:value": getAccountType(getCountryCode(request.recipientDetail.bank.countryCode), request.recipientDetail.bank.accountType)
                  };
              } else {
                  id = {
                      "ns4:key": "accountType",
                      "ns4:value": request.recipientDetail.bank.accountType
                  };
              }

              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
              i++;
          }

          if ("bankCodeType" in request.recipientDetail.bank && 'bankCode' in request.recipientDetail.bank) {

              if ((Object.keys(bankCode).indexOf(request.recipientDetail.bank.bankCodeType) > -1)) {
                  id = {
                      "ns4:key": bankCode[request.recipientDetail.bank.bankCodeType],
                      "ns4:value": request.recipientDetail.bank.bankCode
                  };
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
                  i++;
              } else {
                  id = {
                      "ns4:key": request.recipientDetail.bank.bankCodeType,
                      "ns4:value": request.recipientDetail.bank.bankCode
                  };
                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
                  i++;
              }
          } else if ('bankCode' in request.recipientDetail.bank) {

              id = {
                  "ns4:key": getBankCodeType(getCountryCode(request.recipientDetail.bank.countryCode), getCurrencyCode(request.recipientDetail.bank.currencyCode)),
                  "ns4:value": request.recipientDetail.bank.bankCode
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
              i++;
          }

          if ('branchCode' in request.recipientDetail.bank) {
              id = {
                  "ns4:key": "branchCode",
                  "ns4:value": request.recipientDetail.bank.branchCode
              };
              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
              i++;
          }

          if ('BIC' in request.recipientDetail.bank) {

              if ("countryCode" in request.recipientDetail.bank) {

                  if (Object.keys(swiftBic_Country).indexOf(getCountryCode(request.recipientDetail.bank.countryCode)) > -1) {
                      id = {
                          "ns4:key": "swiftBic",
                          "ns4:value": request.recipientDetail.bank.BIC
                      };
                  } else {
                      id = {
                          "ns4:key": "bic",
                          "ns4:value": request.recipientDetail.bank.BIC
                      };
                  }
              }

              earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"][i] = id;
              i++;
          }

          //delete if bank array is null
          if (earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"].length === 0) {
              delete earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryBankAccount"]["ns4:bankAccountDetails"];
          }

      }

      //#endregion

  }
    //#endregion

    //#region payoutRequestAmount
    if ('transactionDetail' in request) {

        if ('payoutId' in request.transactionDetail) {
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:merchantTransactionReference"] = request.transactionDetail.payoutId;
        }

        if ('settlementCurrencyCode' in request.transactionDetail || 'settlementAmount' in request.transactionDetail) {
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutRequestAmount"] = {};
        }

        if ('settlementCurrencyCode' in request.transactionDetail) {
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutRequestAmount"]["ns1:currency"] = getCurrencyCode(request.transactionDetail.settlementCurrencyCode);
        }

        if ('settlementAmount' in request.transactionDetail && 'settlementCurrencyCode' in request.transactionDetail) {
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payoutRequestAmount"]["ns1:amount"] = parseAmount(request.transactionDetail.settlementAmount, request.transactionDetail.settlementCurrencyCode);
        }
    }

    //#endregion

    //#region beneficiaryAmountInformation
    if ('transactionDetail' in request) {

        if ('destinationCurrencyCode' in request.transactionDetail || 'destinationAmount' in request.transactionDetail || 'settlementCurrencyCode' in request.transactionDetail) {
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryAmountInformation"] = {};
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryAmountInformation"]["ns13:beneficiaryAmount"] = {};
        }
        if ('destinationCurrencyCode' in request.transactionDetail) {
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryAmountInformation"]["ns13:beneficiaryAmount"]["ns1:currency"] = getCurrencyCode(request.transactionDetail.destinationCurrencyCode);
        }

        if ('destinationCurrencyCode' in request.transactionDetail && 'destinationAmount' in request.transactionDetail) {
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryAmountInformation"]["ns13:beneficiaryAmount"]["ns1:amount"] = parseAmount(request.transactionDetail.destinationAmount, request.transactionDetail.destinationCurrencyCode);
        }

        if ('settlementCurrencyCode' in request.transactionDetail) {
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryAmountInformation"]["ns13:payoutCurrency"] = getCurrencyCode(request.transactionDetail.settlementCurrencyCode);
        }
    }


    //#endregion 

    //#region serviceLevel & beneficiaryStatementNarrative
    if ('transactionDetail' in request) {

        if ('payoutSpeed' in request.transactionDetail) {
            if (request.transactionDetail.payoutSpeed == "premium") {
                earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:serviceLevel"] = "express";
            } else {
                earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:serviceLevel"] = request.transactionDetail.payoutSpeed;
            } //need to remove in future
        } else {
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:serviceLevel"] = "standard";
        }

        if ('statementNarrative' in request.transactionDetail) {
            earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:beneficiaryStatementNarrative"] = request.transactionDetail.statementNarrative;
        }
    }
    //#endregion 

    //#region payerType
    earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerType"] = "user";
    //#endregion

    earthportrequest = parse(JSON.stringify(earthportrequest));
    context.setVariable('private.earthportRequest', JSON.stringify(earthportrequest));
    context.setVariable('private.source', "earthportRequest");

} catch (err) {
    context.setVariable("triggerScriptError", true);
    context.setVariable("triggerScriptErrorMessage", err.message);
    throw err.message;
}