/**
   1- payoutDetails 
**/
try
{
   var request=parse(context.getVariable('private.originalRequest').replace(/:\s*(\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d+)\s*([,\}])/g, ':"$1"$2'));
   var earthportrequest=parse(context.getVariable('private.earthportRequest'));
 
   //Writing entire payload to Key-Value pairs  
   var kvArray = [] ;
   kvPayoutDetails({"key":null,"value":request});

   var merchantID=context.getVariable('private.validation_merchantIdentity');

   earthportrequest.payoutDetails = {};

    //#region payoutDetails 
    if("transactionDetail" in request){


          if('payoutSpeed' in request.transactionDetail){
              if(request.transactionDetail.payoutSpeed == "premium"){
                  earthportrequest.payoutDetails.serviceLevel = "express";
              }
              else{
                  earthportrequest.payoutDetails.serviceLevel = request.transactionDetail.payoutSpeed;
              }
          }      // maybe this static logic need to remove in future 
          else{
                  earthportrequest.payoutDetails.serviceLevel = "standard";
          }
          
          //merchantTransactionReference    
          if ('originatorDetail' in request) {
            if ('systemTraceAuditNumber' in request.transactionDetail && 'retrievalReferenceNumber' in request.transactionDetail && 'originatorId' in request.originatorDetail) {
              var merchantTransactionReference = request.transactionDetail.systemTraceAuditNumber + "-"+request.transactionDetail.retrievalReferenceNumber + "-"+request.originatorDetail.originatorId;
              earthportrequest.payoutDetails.merchantTransactionReference = merchantTransactionReference;
            }
          }

          earthportrequest.payoutDetails.beneficiaryStatementNarrative = request.transactionDetail.statementNarrative;
        
          //RAPI-107
          earthportrequest.payoutDetails.amount = parseAmount(request.transactionDetail.destinationAmount,request.transactionDetail.destinationCurrencyCode);

    
          if('destinationCurrencyCode' in request.transactionDetail){
            earthportrequest.payoutDetails.currencyCode = getCurrencyCode(request.transactionDetail.destinationCurrencyCode);
          }

          earthportrequest.payoutDetails.payerType = "user";   
          earthportrequest.payoutDetails.purposeOfPayment = request.transactionDetail.purposeOfPayment;

    }

    earthportrequest.payoutDetails.additionalFields = {};
      
    if ('transactionDetail' in request) {
      
        if ('purposeOfPayment' in request.transactionDetail) {          
          earthportrequest.payoutDetails.additionalFields.PURPOSE_OF_PAYMENT = request.transactionDetail.purposeOfPayment;
        }

        if ('settlementCurrencyCode' in request.transactionDetail) {
          earthportrequest.payoutDetails.additionalFields.FUNDING_CURRENCY = getCurrencyCode(request.transactionDetail.settlementCurrencyCode);
        }
    }

    if ('originatorDetail' in request) {
        if ('bankCountryCode' in request.originatorDetail) {
            earthportrequest.payoutDetails.additionalFields.ORIGINATOR_DETAIL_ACQUIRER_COUNTRY_CODE = getCountryCode(request.originatorDetail.bankCountryCode);
        }
        if ('address' in request.originatorDetail) {
            if ('country' in request.originatorDetail.address) {
              earthportrequest.payoutDetails.additionalFields.ORIGINATOR_DETAIL_MERCHANT_ADDRESS_COUNTRY = getCountryCode(request.originatorDetail.address.country);
            }
        }
        
       //RAPI - 110
        if('bankId' in request.originatorDetail && 'bankBIC' in request.originatorDetail){
           var bankId = request.originatorDetail.bankId;
            if(bankId === 487035 && request.originatorDetail.originatorBIC === undefined){
              earthportrequest.payoutDetails.additionalFields["ORIGINATORDETAIL.ORIGINATORBIC"] = request.originatorDetail.bankBIC;
            }

            if(bankId === 493853 && request.originatorDetail.originatorId === 'MGIS2A000000001'  && request.originatorDetail.originatorBIC === undefined){
             earthportrequest.payoutDetails.additionalFields["ORIGINATORDETAIL.ORIGINATORBIC"] = "MGRMUS44";
            }
            
            if(bankId === 320027 && request.originatorDetail.originatorId === 'CAIDCode77765'  && request.originatorDetail.originatorBIC === undefined){
              earthportrequest.payoutDetails.additionalFields["ORIGINATORDETAIL.ORIGINATORBIC"] = request.originatorDetail.bankBIC;
            }
    
            if(bankId === 426708 && request.originatorDetail.originatorBIC === undefined){
              earthportrequest.payoutDetails.additionalFields["ORIGINATORDETAIL.ORIGINATORBIC"] = request.originatorDetail.bankBIC;
            }
        }else if('bankId' in request.originatorDetail){
         var bankId = request.originatorDetail.bankId;
          if(bankId === 493853 && request.originatorDetail.originatorId === 'MGIS2A000000001'  && request.originatorDetail.originatorBIC === undefined){
            earthportrequest.payoutDetails.additionalFields["ORIGINATORDETAIL.ORIGINATORBIC"] = "MGRMUS44";
          }
        }

    }
    
    if ('recipientDetail' in request) {  
  
      if (Array.isArray(request.recipientDetail.additionalData)) {
        var totalId = request.recipientDetail.additionalData.length;
        if (totalId > 0) {
            for (var i = 0; i < totalId ; i++) {
                if(request.recipientDetail.additionalData[i] !== undefined){
                  if(request.recipientDetail.additionalData[i].name == "KID"){
                    earthportrequest.payoutDetails.additionalFields.KID=request.recipientDetail.additionalData[i].value ;
                  }                  
                }                
              }
            
          }
       }    

      if (Array.isArray(request.recipientDetail.identificationList)) {
      var totalId = request.recipientDetail.identificationList.length;
      if (totalId > 0) {
        for (var i = 0; i < totalId; i++) {
          if(request.recipientDetail.identificationList[i] !== undefined){
            if (request.recipientDetail.identificationList[i].hasOwnProperty("idType") && request.recipientDetail.identificationList[i].hasOwnProperty("idNumber") && request.recipientDetail.identificationList[i].hasOwnProperty("idName")) {
              if(request.recipientDetail.identificationList[i].idType == "T"  && Object.keys(skip_idName).indexOf(request.recipientDetail.identificationList[i].idName) > -1){
                earthportrequest.payoutDetails.additionalFields[skip_idName[request.recipientDetail.identificationList[i].idName]] = request.recipientDetail.identificationList[i].idNumber ;
              }
            }
            } 
        }            
      }
       }
    }
    
    if ('senderDetail' in request) {  
      if (Array.isArray(request.senderDetail.additionalData)) {
        var totalId = request.senderDetail.additionalData.length;
        if (totalId > 0) {
            for (var i = 0; i < totalId; i++) {
                if(request.senderDetail.additionalData[i] !== undefined){
                  if(Object.keys(skip_additionalDataName).indexOf(request.senderDetail.additionalData[i].name) > -1 ){
                    earthportrequest.payoutDetails.additionalFields[skip_additionalDataName[request.senderDetail.additionalData[i].name]]=request.senderDetail.additionalData[i].value;                   
                  }                  
                }                
              }
          }
        }    
    }

    earthportrequest.payoutDetails.additionalFields["TRANSACTIONDETAIL.TRANSACTIONIDENTIFIER"]="1";
      
    for ( var i = 0; i < kvArray.length; i++){     
          earthportrequest.payoutDetails.additionalFields[kvArray[i].key.toUpperCase()]=kvArray[i].value;
    }
   
    //#endregion
    


    earthportrequest=parse(JSON.stringify(earthportrequest));

    context.setVariable('request.header.Merchant-Identity', merchantID);
    context.setVariable('request.content', JSON.stringify(earthportrequest));
    context.setVariable('private.source',"validate_EP_Request");

} catch(err) {  
     context.setVariable("triggerScriptError", true);
     context.setVariable("triggerScriptErrorMessage", err.message);
     throw err.message;
    }