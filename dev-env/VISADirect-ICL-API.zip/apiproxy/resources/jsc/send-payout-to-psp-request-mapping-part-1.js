/**
    1- Contain root element and XML Namespaces for EPS2
    2- payerIdentity values - ( SenderDetails )
**/

try
{

 var request=parse(context.getVariable('request.content').replace(/:\s*(\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d+)\s*([,\}])/g, ':"$1"$2'));

 var earthportrequest = {
   "parameters": {
       "@xmlns": {
           "ns13": "http://customer.endpoint.earthport.com/api/merchant/v1/createOrUpdateUserAddBeneficiaryBankAccountAndPayout",
           "ns1": "http://customer.endpoint.earthport.com/api/merchant/v2/components/core",
           "ns4": "http://customer.endpoint.earthport.com/api/merchant/v3/components/bankBase",
           "ns3": "http://customer.endpoint.earthport.com/api/merchant/v2/components/identityBase",
           "ns8": "http://customer.endpoint.earthport.com/api/merchant/v1/components/payoutBase"
       },
       "ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout": {

       }
   }
 };
 
 var b = {
 "version": "1.2"
 };

 earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["#attrs"] = b;


 //transactionIdentifier   
 if ('transactionDetail' in request) {
   earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:merchantUserIdentity"] = "HashCode";
 }

 //accountCurrency
 earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:accountCurrency"] = "any";
 
 
 //#region payerIdentity  
 if ('senderDetail' in request) {

     var dataCount = 0; // for additionalData increment
     earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"] = {};
             
     if (request.senderDetail.type == 'I') {
               earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"] = {};
               earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:name"] = {};
               earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:name"]["ns3:givenNames"] = request.senderDetail.firstName;
               earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:name"]["ns3:familyName"] = request.senderDetail.lastName;
             
               if ('address' in request.senderDetail) {
                   earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:address"] = {};
                   earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:address"]["ns3:addressLine1"] = request.senderDetail.address.addressLine1;
                   earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:address"]["ns3:addressLine2"] = request.senderDetail.address.addressLine2;
                   earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:address"]["ns3:addressLine3"] = request.senderDetail.address.addressLine3;
                   earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:address"]["ns3:city"] = request.senderDetail.address.city;
                   earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:address"]["ns3:province"] = request.senderDetail.address.province;
                   earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:address"]["ns3:postcode"] = request.senderDetail.address.postalCode;
                   earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:address"]["ns3:country"] = getCountryCode(request.senderDetail.address.country);
               }
             

               if (Array.isArray(request.senderDetail.identificationList)) {
                 var totalId = request.senderDetail.identificationList.length;
                   if (totalId > 0) {

                       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:identificationList"] = {};
                       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:identificationList"]["ns3:identification"] = [];
                 
                       var j=0; // if array contain null value

                       for (var i = 0; i < totalId; i++) {
                          if(request.senderDetail.identificationList[i] !== undefined){                          
                            if(request.senderDetail.identificationList[i].hasOwnProperty("idType") || request.senderDetail.identificationList[i].hasOwnProperty("idNumber") ||  request.senderDetail.identificationList[i].hasOwnProperty("idIssueCountry")){
                              if(Object.keys(idTypeExceptional).indexOf(request.senderDetail.identificationList[i].idType) === -1 ){
                          
                                if(request.senderDetail.identificationList[i].hasOwnProperty("idType") || request.senderDetail.identificationList[i].hasOwnProperty("idNumber") ||  request.senderDetail.identificationList[i].hasOwnProperty("idIssueCountry")){
                                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j]={};
                                }

                          
                                if (Object.keys(idType).indexOf(request.senderDetail.identificationList[i].idType) > -1) {                          
                                    if(request.senderDetail.identificationList[i].hasOwnProperty("idType") ){
                                      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j]["ns3:idType"] = idType[request.senderDetail.identificationList[i].idType];                                
                                    }                          
                                }else{
                                    if(request.senderDetail.identificationList[i].hasOwnProperty("idType") ){
                                      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j]["ns3:idType"] = request.senderDetail.identificationList[i].idType;
                                    }  
                                }                          
                              
                                if(request.senderDetail.identificationList[i].hasOwnProperty("idNumber")) {                                
                                  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j]["ns3:identificationNumber"] = request.senderDetail.identificationList[i].idNumber;
                                }

                                if( request.senderDetail.identificationList[i].hasOwnProperty("idIssueCountry")){                                
                                    earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:identificationList"]["ns3:identification"][j]["ns3:identificationCountry"] =  getCountryCode(request.senderDetail.identificationList[i].idIssueCountry);
                                } 
                          
                              }
                            }
                          j++;
                          }
                       }

                 //delete if additional data is null
                 if(earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:identificationList"]["ns3:identification"].length===0){
                   delete earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:identificationList"];
                 }
                 
               }
              }


             if('countryOfBirth' in request.senderDetail && 'dateOfBirth' in request.senderDetail){
               earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:birthInformation"] = {};
               if('cityOfBirth' in request.senderDetail){
                   earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:birthInformation"]["ns3:cityOfBirth"] = request.senderDetail.cityOfBirth;
               }
               earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:birthInformation"]["ns3:countryOfBirth"] = getCountryCode(request.senderDetail.countryOfBirth);
               earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerIndividualIdentity"]["ns3:birthInformation"]["ns3:dateOfBirth"] = request.senderDetail.dateOfBirth;
           }

     }
     else if (request.senderDetail.type == 'C') {
       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"] = {};
       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:legalEntityName"] = request.senderDetail.companyName;


       if (Array.isArray(request.senderDetail.identificationList)) {
         var totalId = request.senderDetail.identificationList.length;
         if (totalId > 0) {
           
           if(request.senderDetail.identificationList[0] !== undefined){

               if(request.senderDetail.identificationList[0].hasOwnProperty("idType")){
                   if(request.senderDetail.identificationList[0].idType === "L"){
                     if(request.senderDetail.identificationList[0].hasOwnProperty("idNumber") ||  request.senderDetail.identificationList[0].hasOwnProperty("idIssueCountry")){
                       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:legalEntityRegistration"] = {};         
                     }
       
                     if(request.senderDetail.identificationList[0].hasOwnProperty("idNumber")) {                                
                       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:legalEntityRegistration"]["ns3:legalEntityRegistrationNumber"] = request.senderDetail.identificationList[0].idNumber;
                     }
       
                     if( request.senderDetail.identificationList[0].hasOwnProperty("idIssueCountry")){                                
                       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:legalEntityRegistration"]["ns3:legalEntityRegistrationCountry"] = getCountryCode(request.senderDetail.identificationList[0].idIssueCountry);
                     }            
       
                 }

               }

           }           
             
         }
       }
       
       if ('address' in request.senderDetail) {
           earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:address"] = {};
           earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:address"]["ns3:addressLine1"] = request.senderDetail.address.addressLine1;
           earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:address"]["ns3:addressLine2"] = request.senderDetail.address.addressLine2;
           earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:address"]["ns3:addressLine3"] = request.senderDetail.address.addressLine3;
           earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:address"]["ns3:city"] = request.senderDetail.address.city;
           earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:address"]["ns3:province"] = request.senderDetail.address.province;
           earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:address"]["ns3:postcode"] = request.senderDetail.address.postalCode;
           earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:payerLegalEntityIdentity"]["ns3:address"]["ns3:country"] = getCountryCode(request.senderDetail.address.country);
       }

     }

     //#region  AdditionalDataList 
     // 1) identificationList
     if (Array.isArray(request.senderDetail.identificationList)) {
       var totalId = request.senderDetail.identificationList.length;
       if (totalId > 0) {
         earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"] = {};
         earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"]["ns3:additionalData"] = [];

         for (var i = 0; i < totalId; i++) {
           if(request.senderDetail.identificationList[i] !== undefined){       
             
             if ((request.senderDetail.identificationList[i].hasOwnProperty("idType") && request.senderDetail.identificationList[i].hasOwnProperty("idNumber")) || request.senderDetail.identificationList[i].hasOwnProperty("idName")) {
                  if(Object.keys(idTypeExceptional).indexOf(request.senderDetail.identificationList[i].idType) > -1 ){
                    //logic for idType F - ForeginID
                    if(request.senderDetail.identificationList[i].idType == "F" && request.senderDetail.identificationList[i].hasOwnProperty("idNumber")){
                      if(request.senderDetail.identificationList[i].hasOwnProperty("idName")){
                        var id = {
                          "ns3:additionalDataKey": request.senderDetail.identificationList[i].idName,
                          "ns3:additionalDataValue": request.senderDetail.identificationList[i].idNumber
                        };
                      }else{
                        var id = {
                          "ns3:additionalDataKey": "FOREIGN_ID",
                          "ns3:additionalDataValue": request.senderDetail.identificationList[i].idNumber
                        };
                      }
                      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                      dataCount++;
                    }else if(request.senderDetail.identificationList[i].hasOwnProperty("idNumber") && request.senderDetail.identificationList[i].hasOwnProperty("idName")){
                      var id = {
                        "ns3:additionalDataKey": request.senderDetail.identificationList[i].idName,
                        "ns3:additionalDataValue": request.senderDetail.identificationList[i].idNumber
                      };
                      earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
                      dataCount++;
                    }
               }
             }
           }            
         }   
       }
     }

      //create addtionalData Block if not created
       if(!("ns3:additionalDataList" in  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"])){
           earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"] = {};
           earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"]["ns3:additionalData"] = [];
       }
      

     // 2) AdditionalData 
     if (Array.isArray(request.senderDetail.additionalData)) {
       var totalId = request.senderDetail.additionalData.length;
       if (totalId > 0) {

         for (var i = 0; i < totalId; i++) {
           if(request.senderDetail.additionalData[i] !== undefined){
             if(Object.keys(skip_additionalDataName).indexOf(request.senderDetail.additionalData[i].name) == -1 ){
               var id = {
                 "ns3:additionalDataKey": request.senderDetail.additionalData[i].name,
                 "ns3:additionalDataValue": request.senderDetail.additionalData[i].value
               };
               earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
               dataCount++;
             }
           }              
         }
       }
     }

 
     // 3) contactNumber
     if("contactNumber" in request.senderDetail){
       var id = {
         "ns3:additionalDataKey": "MOBILE_PHONE_NUMBER",
         "ns3:additionalDataValue": request.senderDetail.contactNumber
       };
       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
       dataCount++;

    }
     
     // 4) contactEmail
     if("contactEmail" in request.senderDetail){

       var id = {
         "ns3:additionalDataKey": "EMAIL_ADDRESS",
         "ns3:additionalDataValue": request.senderDetail.contactEmail
       };
       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
       dataCount++;
     }

     // 5) senderReferenceNumber
     if("senderReferenceNumber" in request.senderDetail){

       var id = {
         "ns3:additionalDataKey": "PAYER_ACCOUNT_NUMBER",
         "ns3:additionalDataValue": request.senderDetail.senderReferenceNumber
       };
       earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"]["ns3:additionalData"][dataCount] = id;
       dataCount++;
     }

      //delete if additional data is null
      if(("ns3:additionalDataList" in  earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"])){
       if( earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"]["ns3:additionalData"].length===0){
         delete earthportrequest.parameters["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]["ns3:additionalDataList"];
       } 
     }
     
             
    //#endregion

 } 
   //#endregion payerIdentity
   
 earthportrequest=parse(JSON.stringify(earthportrequest));

 var sender_hashValue="";

 if("ns13:payerIdentity" in earthportrequest["parameters"]["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]){
   getPayerDetails(JSON.stringify(earthportrequest["parameters"]["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:payerIdentity"]));
 }

 if(sender_hashValue !== null){
   if("ns13:merchantUserIdentity" in earthportrequest["parameters"]["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]){
     var _sha256 = crypto.getSHA256();
     _sha256.update(sender_hashValue);
     var _hashed_token = _sha256.digest();
     earthportrequest["parameters"]["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:merchantUserIdentity"] = _hashed_token;
  }  
 }else{
    if("ns13:merchantUserIdentity" in earthportrequest["parameters"]["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]){
     earthportrequest["parameters"]["ns13:createOrUpdateUserAddBeneficiaryBankAccountAndPayout"]["ns13:merchantUserIdentity"]=undefined;
   } 
 }


 context.setVariable('private.earthportRequest', JSON.stringify(earthportrequest));
 context.setVariable('private.originalRequest', JSON.stringify(request));
 context.setVariable('private.source',"earthportRequest");

} catch(err) {  
     context.setVariable("triggerScriptError", true);
     context.setVariable("triggerScriptErrorMessage", err.message);
     throw err.message;
    }
