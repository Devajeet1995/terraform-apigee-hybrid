try {
	var payoutId = context.getVariable('payoutId');

	var latestrequest = {
		"parameters": {
			"@xmlns": {
				"ns20": "http://customer.endpoint.earthport.com/api/merchant/v2/services/cancellationRequest"
			},
			"ns20:cancellationRequest": {
			}
		}
	};

	var b = {
		"version": "2.0"
	};

	latestrequest.parameters["ns20:cancellationRequest"]["#attrs"] = b;
	
    // latestrequest.parameters["ns20:cancellationRequest"]["ns20:epTransactionID"] = payoutId;
    latestrequest.parameters["ns20:cancellationRequest"]["ns20:merchantTransactionReference"] = payoutId;



	context.setVariable('request.content', JSON.stringify(latestrequest));
    context.setVariable('private.source',"earthportRequest");

} catch (err) {
    context.setVariable("triggerScriptError", true);
    context.setVariable("triggerScriptErrorMessage", err.message);
   	throw err.message;
}