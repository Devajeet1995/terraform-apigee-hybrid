var messageContent=IsValidJSONString(context.getVariable('message.content'));
var messageID=context.getVariable("messageid");
var statusCode=context.getVariable('message.status.code');
var source = context.getVariable('private.source');  
var logMessage = context.getVariable('private.logMessage');  
var headerNames = String(context.getVariable('request.headers.names'));
var uniqueId = context.getVariable('private.uuid');
var pathsuffix = context.getVariable('proxy.pathsuffix');
var req_scheme = context.getVariable('client.scheme');
var req_host = context.getVariable('request.header.host');
var req_request_uri = context.getVariable('request.uri');
var req_url = req_scheme + "://" + req_host + req_request_uri;
var tag=context.getVariable('organization.name')+"."+context.getVariable('apiproxy.name')+"."+context.getVariable('environment.name');
var logLevel="INFO"; //default INFO

if(context.getVariable('private.isDataMasking') === "false" && context.getVariable('environment.name') !== "production"){
  var maskData=false;
}else{
  var maskData=true;
}

//#region timestamp Code according to earthport
var timestamp = context.getVariable("system.timestamp");
var currDate = new Date(timestamp);
var dateTimeIsoString = currDate.toISOString();
// split by dot
var currDateTime = dateTimeIsoString.replace(/Z+$/, '');
var timeZoneOffset = currDate.getTimezoneOffset();
var positiveOffset = Math.abs(timeZoneOffset);
var timeOffsetInHours = -(timeZoneOffset/60);
var minZone = (positiveOffset - Math.floor(timeOffsetInHours) * 60);
var symbolOffset = timeZoneOffset > 0 ? '-' : '+' ;
var hourOffset = Math.floor(timeOffsetInHours) < 10 ? 0 : '';
var minOffset = minZone < 10 ? 0 : '';
var tzd = symbolOffset + hourOffset + Math.floor(timeOffsetInHours) + ":" + minOffset + minZone ;
var dateTZDformat = currDateTime + tzd;
//#endregion


//#region  masking function 

function maskValue(str) {
  return str.replace(/[a-zA-Z0-9 \.\_\-\:\@]/g, function () {
      return "*";
  });
}

flag=false;


function maskRequestPayload(jsonPayload,visaKeyFields,earthportKeyFields,earthportArrayFields){
  return JSON.parse(jsonPayload, function (key, value) {
  
    if(maskData){
        if((visaKeyFields.indexOf(key))> -1){
            return  maskValue(value.toString());
          }

          if(key === "ns8:value" ){
            return  maskValue(value.toString());
          }

          if(flag===true){
              flag=false;
              return  maskValue(value.toString());                  
          }

          if((earthportArrayFields.indexOf(value))> -1){
              flag=true;
          }

          if((earthportKeyFields.indexOf(key))> -1){
            return  maskValue(value.toString());
          }
        
        //return default values
         return value;
    }else{
        return value;
    }

  });
 }


function IsValidJSONString(str) {
  try {
    return JSON.parse(str);
  } catch (e) {
      errorMessage={};
      errorMessage.Invalid_JSON=str;
      return errorMessage;
  }
}

function createLog(modifiedRes,new_source,LL){
  return  dateTZDformat +"  logLevel = "+ JSON.stringify(LL) +"  UUID = "+ JSON.stringify(uniqueId) + " APIGEE_REQUEST_MESSAGE_ID = "+ JSON.stringify(messageID) +"  ENDPOINT = " +JSON.stringify(pathsuffix) +"  TAG = " + JSON.stringify(tag) +"  SOURCE = " +JSON.stringify(new_source) +"  "+modifiedRes+'\n\n' ;
}
//#endregion

function createHeaderLog(hNames,LL){
   // convert the list of header names to an array:
   var headerList = hNames.substring(1, hNames.length - 1).split(new RegExp(', ', 'g'));
   var requestInfo = {};
   headerList.forEach(function(headerName) {
     requestInfo[headerName] = context.getVariable('request.header.' + headerName);
   });
   requestInfo.CLIENT_REQUEST_URL=req_url;

   //for header
   new_source="Visa Request Info "
   logMessage= createLog(JSON.stringify(requestInfo),new_source,LL);
 
}

//visa Request PII key names
var visa_requestValues=["bankBIC","group","name","value","firstName","lastName","companyName","accountNumber","accountName","branchCode","addressLine","addressLine1","addressLine2","addressLine3","postalCode","idNumber","contactNumber","contactEmail","dateOfBirth"];

// earthport Request PII key names 
var EP_requestKV=["iban","sortCode","bankCode","abaRoutingNumber","accountNumber","accountName","branchCode","RUC","RUT","CUIL","CUIT","FOREIGN_ID"];
var EP_requestValues=["ns3:givenNames","ns3:familyName","ns3:addressLine1","ns3:addressLine2","ns3:addressLine3","ns3:postcode","ns3:identificationNumber"];

//validate EP Request fields -
var validate_requestValues=["identificationNumber","givenNames","familyName","mobileTelephoneNumber","homeTelephoneNumber","businessTelephoneNumber","date","bic","iban","abaRoutingNumber","propertyValue","addressLine1","addressLine2","addressLine3","postalCode","companyName","branchCode","sortCode","accountNumber"];

if(messageContent.shortMsg === "Internal Execution Error"){
    var req=context.getVariable('request.content');
    new_source="Error Occur In APIGEE - Visa Request ";
    modifiedRes= "PAYLOAD="+ JSON.stringify(req);  
    logLevel="ALERT";
    logMessage = logMessage + createLog(modifiedRes,new_source,logLevel);

    //error log 
    logLevel="ERROR";
    modifiedRes= "statusCode="+ JSON.stringify(statusCode.toString()) +"  PAYLOAD= "+ JSON.stringify(messageContent);  
    logMessage = logMessage + createLog(modifiedRes,source,logLevel);

}else if((messageContent.longMsg == "Invalid json format: "+ context.getVariable("triggerSchemaValidationMessage")) || messageContent.longMsg === "Content-Type header is missing or invalid"){


    createHeaderLog(headerNames,logLevel);

    var req=context.getVariable('request.content');
    new_source="Visa Enc Request";
    modifiedRes= "ENCRYPTED PAYLOAD= "+ JSON.stringify(req);  
    logLevel="ERROR";
    logMessage = logMessage + createLog(modifiedRes,new_source,logLevel);

    //error log 
    logLevel="ERROR";
    modifiedRes= "statusCode ="+ JSON.stringify(statusCode.toString()) +"  PAYLOAD= "+ JSON.stringify(messageContent);  
    logMessage = logMessage + createLog(modifiedRes,source,logLevel);

}else if(source == "visaRequest"){
  
    createHeaderLog(headerNames,logLevel);

   if(messageContent.Invalid_JSON === ""){
     modifiedRes="PAYLOAD = "+JSON.stringify("Empty Request Body") ;
   }else {
     modifiedRes="PAYLOAD = " + JSON.stringify(maskRequestPayload(JSON.stringify(messageContent),visa_requestValues,EP_requestValues,EP_requestKV));
   }
    //for visa Request
    logMessage = logMessage + createLog(modifiedRes,source,logLevel);

}else if(source == "earthportRequest"){
    modifiedRes="PAYLOAD = " + JSON.stringify(maskRequestPayload(JSON.stringify(messageContent),visa_requestValues,EP_requestValues,EP_requestKV));
    logMessage = logMessage + createLog(modifiedRes,source,logLevel);

}else if(source == "validate_EP_Request"){
       modifiedRes=JSON.parse(JSON.stringify(maskRequestPayload(JSON.stringify(messageContent),validate_requestValues,EP_requestValues,EP_requestKV)));
       if("payoutDetails" in modifiedRes){
         if("additionalFields" in modifiedRes.payoutDetails){
            var keyNames=Object.keys(modifiedRes.payoutDetails.additionalFields);
            modifiedRes="PAYLOAD= " + JSON.stringify(maskRequestPayload(JSON.stringify(modifiedRes),keyNames,EP_requestValues,EP_requestKV));
            logMessage = logMessage + createLog(modifiedRes,source,logLevel);
         }
       }
}else if((source == "earthportResponse") || source =="visaResponse"){
  modifiedRes= "statusCode=" + JSON.stringify(statusCode.toString()) +"  PAYLOAD="+ JSON.stringify(messageContent);  
  logMessage = logMessage + createLog(modifiedRes,source,logLevel);

}else if(source == "errorResponse") {
    
  if(statusCode >= 500){
    logLevel="ALERT";
    modifiedRes= "statusCode="+ JSON.stringify(statusCode.toString()) +"  PAYLOAD="+ JSON.stringify(messageContent);  
    logMessage = logMessage + createLog(modifiedRes,source,logLevel);

  }else{
    logLevel="ERROR";
    modifiedRes= "statusCode="+ JSON.stringify(statusCode.toString()) +"  PAYLOAD="+ JSON.stringify(messageContent);  
    logMessage = logMessage + createLog(modifiedRes,source,logLevel);
  }
}



context.setVariable('private.logMessage', logMessage);

// print(uniqueId);


