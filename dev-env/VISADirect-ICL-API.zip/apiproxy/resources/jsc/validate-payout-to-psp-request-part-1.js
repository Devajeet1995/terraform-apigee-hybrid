/**
   1- beneficiaryBankAccount ( recipientDetail )
**/

try
{

    var request=parse(context.getVariable('request.content').replace(/:\s*(\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d+)\s*([,\}])/g, ':"$1"$2'));
    var earthportrequest = {};

    var merchantID=context.getVariable('private.validation_merchantIdentity');
    var fullName = false; // for unstructured 

    if(merchantID !== ""){
      earthportrequest.merchantID=merchantID;
    }

    //#region beneficiaryBankAccount 
    if ('recipientDetail' in request) {
      var dataCount = 0;
       earthportrequest.beneficiaryBankAccount = {};
    //   earthportrequest.beneficiaryBankAccount.beneficiaryIdentity = {};

        if ("fullName" in request.recipientDetail) {
          fullName = true;
        }

        if ((request.recipientDetail.type == 'I') && !(fullName)) {
               earthportrequest.beneficiaryBankAccount.beneficiaryIdentity = {};
              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityType = "beneficiaryIndividual";

              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.active = true;


                if (Array.isArray(request.recipientDetail.identificationList)) {
                    var totalId = request.recipientDetail.identificationList.length;
                    if (totalId > 0) {
                    
                    earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identificationList = [];
                  
                    var j=0; // if array contain null value

                    for (var i = 0; i < totalId; i++) {

                        if(request.recipientDetail.identificationList[i] !== undefined){
                        if(request.recipientDetail.identificationList[i].hasOwnProperty("idType")){

                              if ((Object.keys(idTypeExceptional).indexOf(request.recipientDetail.identificationList[i].idType) === -1) && skipIdentificationList(request.recipientDetail.identificationList[i].idType,getCountryCode(request.recipientDetail.bank.countryCode))) {

                            if(request.recipientDetail.identificationList[i].hasOwnProperty("idType")  || request.recipientDetail.identificationList[i].hasOwnProperty("idNumber") ||  request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")){
                                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identificationList[j]={};
                            }
              
                            if (Object.keys(idType).indexOf(request.recipientDetail.identificationList[i].idType) > -1) {
                      
                                if(request.recipientDetail.identificationList[i].hasOwnProperty("idType") ){
                                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identificationList[j].identificationNumberType = idType[request.recipientDetail.identificationList[i].idType];
                                }
                            }else{ 
                                if(request.recipientDetail.identificationList[i].hasOwnProperty("idType") ){
                                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identificationList[j].identificationNumberType = request.recipientDetail.identificationList[i].idType;
                                }  
                      
                            }

                            if(request.recipientDetail.identificationList[i].hasOwnProperty("idNumber")) {                                
                                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identificationList[j].identificationNumber = request.recipientDetail.identificationList[i].idNumber;
                            }
      
                            if( request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")){                                
                            earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identificationList[j].identificationCountry =  getCountryCode(request.recipientDetail.identificationList[i].idIssueCountry);
                            }else{
                              if("bank" in request.recipientDetail){   
                                if("countryCode" in request.recipientDetail.bank){   
                                  earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identificationList[j].identificationCountry = getCountryCode(request.recipientDetail.bank.countryCode);
                                }   
                              }
                            } 
                            j++;

                            }
                        }
                        }
                    
                    }
                    }
                }

              if("firstName" in request.recipientDetail && "lastName" in request.recipientDetail){
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityName = request.recipientDetail.firstName+" "+request.recipientDetail.lastName;
              }

              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.givenNames = request.recipientDetail.firstName;
              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.familyName = request.recipientDetail.lastName;
              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.mobileTelephoneNumber = request.recipientDetail.contactNumber;


              if('countryOfBirth' in request.recipientDetail && 'dateOfBirth' in request.recipientDetail){

                  earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.birthInformation = {};
                  if('cityOfBirth' in request.recipientDetail){
                        earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.birthInformation.city = request.recipientDetail.cityOfBirth;            
                  }
                  earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.birthInformation["country.name"] = getCountryCode(request.recipientDetail.countryOfBirth);         
                  earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.birthInformation.date = request.recipientDetail.dateOfBirth;
                }
              
        }else if (request.recipientDetail.type == 'C') {
            earthportrequest.beneficiaryBankAccount.beneficiaryIdentity = {};
            earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityType = "beneficiaryCompany";
            earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.active = true;

            if(fullName){
              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityName = request.recipientDetail.fullName;
              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.companyName = request.recipientDetail.fullName;

            }else{
              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityName = request.recipientDetail.companyName;
              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.companyName = request.recipientDetail.companyName;

            }
        
            if (Array.isArray(request.recipientDetail.identificationList)) {
              var totalId = request.recipientDetail.identificationList.length;
              if (totalId > 0) {

                if(request.recipientDetail.identificationList[0] !== undefined){

                    if(request.recipientDetail.identificationList[0].hasOwnProperty("idType")){

                        if(request.recipientDetail.identificationList[0].idType ==="L"){
                    
                            if(request.recipientDetail.identificationList[0].hasOwnProperty("idNumber") ||  request.recipientDetail.identificationList[0].hasOwnProperty("idIssueCountry")){
                                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.companyRegistration = {};
                              }
          
                              if(request.recipientDetail.identificationList[0].hasOwnProperty("idNumber")) {                                
                                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.companyRegistration.companyRegistrationNumber = request.recipientDetail.identificationList[0].idNumber; 
                              }
                              if( request.recipientDetail.identificationList[0].hasOwnProperty("idIssueCountry")){                                
                                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.companyRegistration["companyRegistrationCountry.name"] = getCountryCode(request.recipientDetail.identificationList[0].idIssueCountry);
                              }else{
                                if("bank" in request.recipientDetail){   
                                  if("countryCode" in request.recipientDetail.bank){   
                                    earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.companyRegistration["companyRegistrationCountry.name"]  = getCountryCode(request.recipientDetail.bank.countryCode);
                                  }   
                                }
                              }  
                            }                              
                        }
                        }
                      }
            } 
        
         }else if((request.recipientDetail.type === undefined) || (request.recipientDetail.type == "I" && fullName)){
            earthportrequest.beneficiaryBankAccount.beneficiaryIdentity = {};
            earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityType = "beneficiaryUnstructured";

            var identityData = 0;
            earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityData=[];

            if("type" in request.recipientDetail){
              var id = {
                "key": "IdentityType",
                "value": request.recipientDetail.type
                };
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityData[identityData++] = id;
            }

            if('fullName' in request.recipientDetail){
              var id = {
                "key": "Name",
                "value": request.recipientDetail.fullName
                };
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityData[identityData++] = id;
            }

            if('address' in request.recipientDetail){
              if('addressLine1' in request.recipientDetail.address){
                id = {
                   "key": "AddressLine1",
                   "value": request.recipientDetail.address.addressLine1
                   };
                   earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityData[identityData++] = id;
               }
   
               if('addressLine2' in request.recipientDetail.address){
                id = {
                   "key": "AddressLine2",
                   "value": request.recipientDetail.address.addressLine2
                   };
                   earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityData[identityData++] = id;
               }
   
               if('addressLine3' in request.recipientDetail.address){
                id = {
                   "key": "AddressLine3",
                   "value": request.recipientDetail.address.addressLine3
                   };
                   earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityData[identityData++] = id;
               }
   
               if('country' in request.recipientDetail.address){
                id = {
                   "key": "Country",
                   "value": getCountryCode(request.recipientDetail.address.country)
                   };
                   earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityData[identityData++] = id;
               }
   
               if('city' in request.recipientDetail.address){
                id = {
                   "key": "City",
                   "value": request.recipientDetail.address.city
                   };
                   earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityData[identityData++] = id;
               }
   
               if('province' in request.recipientDetail.address){
                id = {
                   "key": "Province",
                   "value": request.recipientDetail.address.province
                   };
                   earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityData[identityData++] = id;
               }
   
               if('postalCode' in request.recipientDetail.address){
                id = {
                   "key": "Postcode",
                   "value": request.recipientDetail.address.postalCode
                   };
                   earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityData[identityData++] = id;
               }   
            }

            if('countryOfBirth' in request.recipientDetail || 'dateOfBirth' in request.recipientDetail || 'cityOfBirth' in request.recipientDetail ){

              if(!("additionalData" in earthportrequest.beneficiaryBankAccount.beneficiaryIdentity)){
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData = [];
              }

              if('countryOfBirth' in request.recipientDetail){
                var id = {
                  "propertyType": "ISO_COUNTRY_CODE_OF_BIRTH",
                  "propertyValue": getCountryCode(request.recipientDetail.countryOfBirth)
                  };
                  earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount++] = id;
              }

              if('cityOfBirth' in request.recipientDetail){
                var id = {
                  "propertyType": "PLACE_OF_BIRTH",
                  "propertyValue": request.recipientDetail.cityOfBirth
                  };
                  earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount++] = id;
              }

              if('dateOfBirth' in request.recipientDetail){
                var id = {
                  "propertyType": "DATE_OF_BIRTH",
                  "propertyValue": request.recipientDetail.dateOfBirth
                  };
                  earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount++] = id;
              }
            }

            if (Array.isArray(request.recipientDetail.identificationList)) {
              var totalId = request.recipientDetail.identificationList.length;
              
               if(!("additionalData" in earthportrequest.beneficiaryBankAccount.beneficiaryIdentity)){
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData = [];
              }

              if (totalId > 0) {

                  for (var i = 0; i < totalId; i++) {

                      if (request.recipientDetail.identificationList[i] !== undefined) {

                          if (request.recipientDetail.identificationList[i].hasOwnProperty("idType") || request.recipientDetail.identificationList[i].hasOwnProperty("idNumber") || request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")) {
                              if (Object.keys(idTypeExceptional).indexOf(request.recipientDetail.identificationList[i].idType) === -1) {
                                  if (Object.keys(idTypeAdditional).indexOf(request.recipientDetail.identificationList[i].idType) > -1) {
                                      if (request.recipientDetail.identificationList[i].hasOwnProperty("idType")) {
                                        var id = {
                                          "propertyType": idTypeAdditional[request.recipientDetail.identificationList[i].idType],
                                          "propertyValue": request.recipientDetail.identificationList[i].idNumber
                                        }
                                        earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount++] = id;
                                      }

                                  } else {
                                      if (request.recipientDetail.identificationList[i].hasOwnProperty("idType")) {
                                          var id = {
                                              "propertyType": request.recipientDetail.identificationList[i].idType,
                                              "propertyValue": request.recipientDetail.identificationList[i].idNumber
                                            }
                                            earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount++] = id;
                                          }
                                  }

                                  if (request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")) {
                                      var id = {
                                          "propertyType": "ISO_COUNTRY_CODE_ID_ISSUER",
                                          "propertyValue": getCountryCode(request.recipientDetail.identificationList[i].idIssueCountry)
                                        }
                                        earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount++] = id;

                                  } else {
                                      if ("bank" in request.recipientDetail) {
                                          if ("countryCode" in request.recipientDetail.bank) {
                                              var id = {
                                                  "propertyType": "ISO_COUNTRY_CODE_ID_ISSUER",
                                                  "propertyValue": getCountryCode(request.recipientDetail.bank.countryCode)
                                                }
                                                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount++] = id;
                                          }
                                      }
                                  }
                              }
                          }
                      }
                  }
              }
          }

         }


        //for recipientDetail both I and C 
        //  if(request.recipientDetail.type == 'I' || request.recipientDetail.type == 'C' || fullName){
  
              // //Additional data -- identificationList
              if (Array.isArray(request.recipientDetail.identificationList)) {
                var totalId = request.recipientDetail.identificationList.length;
                if (totalId > 0) {
                  
                  if(!("additionalData" in earthportrequest.beneficiaryBankAccount.beneficiaryIdentity)){
                    earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData = [];
                  }
                    for (var i = 0; i < totalId; i++) {

                      if(request.recipientDetail.identificationList[i] !== undefined){
                      
                        if ((request.recipientDetail.identificationList[i].hasOwnProperty("idType") && request.recipientDetail.identificationList[i].hasOwnProperty("idNumber")) || request.recipientDetail.identificationList[i].hasOwnProperty("idName")) {
                          if(Object.keys(idTypeExceptional).indexOf(request.recipientDetail.identificationList[i].idType) > -1  && Object.keys(skip_idName).indexOf(request.recipientDetail.identificationList[i].idName) == -1){
                            if(request.recipientDetail.identificationList[i].idType == "F" && request.recipientDetail.identificationList[i].hasOwnProperty("idNumber")){
                              if(request.recipientDetail.identificationList[i].hasOwnProperty("idName")){
                                var id = {
                                  "propertyType": request.recipientDetail.identificationList[i].idName,
                                  "propertyValue": request.recipientDetail.identificationList[i].idNumber
                                };
                              }else{
                                var id = {
                                  "propertyType": "FOREIGN_ID",
                                  "propertyValue": request.recipientDetail.identificationList[i].idNumber
                                };
                              }
                              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount] = id;
                              dataCount++;
                           
                            }else if(request.recipientDetail.identificationList[i].hasOwnProperty("idNumber") && request.recipientDetail.identificationList[i].hasOwnProperty("idName")){
                              var id = {
                                "propertyType": request.recipientDetail.identificationList[i].idName,
                                "propertyValue": request.recipientDetail.identificationList[i].idNumber
                              };
                              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount] = id;
                              dataCount++;
                             }
                          }
                        }

                        //country specific logic for costa rica 
                        if (request.recipientDetail.identificationList[i].hasOwnProperty("idType") && request.recipientDetail.identificationList[i].hasOwnProperty("idNumber")) {
                      if(request.recipientDetail.identificationList[i].idType == "N"){
                        if(request.recipientDetail.identificationList[i].hasOwnProperty("idIssueCountry")){
                          if(getCountryCode(request.recipientDetail.identificationList[i].idIssueCountry) == "CR"){
                            var id = {
                              "propertyType": "NATIONAL_ID_CARD" ,
                              "propertyValue": request.recipientDetail.identificationList[i].idNumber
                              };
                              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount] = id;
                              dataCount++;     
                          }
  
                        }else if("bank" in request.recipientDetail){   
                          if("countryCode" in request.recipientDetail.bank){ 
                            if(getCountryCode(request.recipientDetail.bank.countryCode) == "CR"){
                              var id = {
                                "propertyType": "NATIONAL_ID_CARD" ,
                                "propertyValue": request.recipientDetail.identificationList[i].idNumber
                              };
                                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount] = id;
                                dataCount++;     
                            }
                          }                   
                        }
                      }
                        }
                      }
                    }
                }
              }
            
              if (Array.isArray(request.recipientDetail.additionalData)) {
                var totalId = request.recipientDetail.additionalData.length;
                if (totalId > 0) {
                
                  if(!("additionalData" in earthportrequest.beneficiaryBankAccount.beneficiaryIdentity)){
                    earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData = [];
                  }

                  for (var i = 0; i < totalId; i++) {
                    if(request.recipientDetail.additionalData[i] !== undefined){
    
                      if(Object.keys(skip_additionalDataName).indexOf(request.recipientDetail.additionalData[i].name) == -1 ){
                        var id = {
                          "propertyType": (Object.keys(additionalDataName).indexOf(request.recipientDetail.additionalData[i].name) > -1) ? additionalDataName[request.recipientDetail.additionalData[i].name] : request.recipientDetail.additionalData[i].name ,
                          "propertyValue": request.recipientDetail.additionalData[i].value
                          };
                          earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount] = id;
                          dataCount++;                               
                      }
                    }
                  }

                }

              }

              //for the contact Number
              if("contactNumber" in request.recipientDetail){
                var contactFlag=false;
              
                      if(!("additionalData" in earthportrequest.beneficiaryBankAccount.beneficiaryIdentity)){
                        earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData = [];
                      }

                      if ('bank' in request.recipientDetail) {
                        if("countryCode" in request.recipientDetail.bank ){
                          if(getCountryCode(request.recipientDetail.bank.countryCode) == "TR"){
                            var id = {
                              "propertyType": "INTERNATIONAL_PHONE_NUMBER",
                              "propertyValue": request.recipientDetail.contactNumber
                              };
                              earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount] = id;
                              dataCount++;
                            contactFlag=true;
                          }
                        }     
                      
                      }
                    
                      if(contactFlag==false){
                        var id = {
                          "propertyType": "MOBILE_PHONE_NUMBER",
                          "propertyValue": request.recipientDetail.contactNumber
                          };
                          earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount] = id;
                          dataCount++;
                      }    
              
              }
                
              //for the contactEmail
              if("contactEmail" in request.recipientDetail){
                
                    if(dataCount>0){
                        var id = {
                            "propertyType": "EMAIL_ADDRESS",
                            "propertyValue": request.recipientDetail.contactEmail
                        };
                        earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount] = id;
                        dataCount++;
                        }
                    else{
                        earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData = [];
                         var id = {
                          "propertyType": "EMAIL_ADDRESS",
                          "propertyValue": request.recipientDetail.contactEmail
                        };
                        earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.additionalData[dataCount] = id;
                        dataCount++;     
                    }
              }

              //Address
              if (('address' in request.recipientDetail) && earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.identityType !== "beneficiaryUnstructured" ) {
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.address = {};
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.address.addressLine1 = request.recipientDetail.address.addressLine1;
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.address.addressLine2 = request.recipientDetail.address.addressLine2;
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.address.addressLine3 = request.recipientDetail.address.addressLine3;
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.address.city = request.recipientDetail.address.city;
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.address.province = request.recipientDetail.address.province;
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.address.postCode = request.recipientDetail.address.postalCode;
                earthportrequest.beneficiaryBankAccount.beneficiaryIdentity.address["country.name"] = getCountryCode(request.recipientDetail.address.country);
              }
        // }    

        

        if(merchantID !== ""){
          earthportrequest.beneficiaryBankAccount.merchantID=merchantID;
        }
        
          //bankAccountDetails
          if ('bank' in request.recipientDetail) {

            //for Czech Republic
            if(getCountryCode(request.recipientDetail.bank.countryCode) == "CZ" ){
              if("accountNumber" in request.recipientDetail.bank){
                if(request.recipientDetail.bank.accountNumber.includes("/") && request.recipientDetail.bank.accountNumber.includes("-")){
                    accountInfo=request.recipientDetail.bank.accountNumber.split("-");
                    request.recipientDetail.bank.accountNumberPrefix=accountInfo[0];
                    accountInfo=accountInfo[1].split("/");
                    request.recipientDetail.bank.accountNumberType="DEFAULT";
                    request.recipientDetail.bank.accountNumber=accountInfo[0];
                    request.recipientDetail.bank.bankCodeType="DEFAULT";
                    request.recipientDetail.bank.bankCode=accountInfo[1];                      
                    }                        
              }

          }
   
             //country specific logic - RAPI 98 
             if(getCountryCode(request.recipientDetail.bank.countryCode) == "NZ" ){
               
              if('accountNumber' in request.recipientDetail.bank ){
                  var accountNumber_Value=request.recipientDetail.bank.accountNumber;
                  var accountNumber_length=request.recipientDetail.bank.accountNumber.length;
    
                  if(accountNumber_length > 7 && request.recipientDetail.bank.accountNumberSuffix === undefined ){
                      var accountNumberSuffix=accountNumber_Value.substring(7);
                      accountNumber_Value=accountNumber_Value.substring(0,7);     
                      request.recipientDetail.bank.accountNumber=accountNumber_Value;
                      request.recipientDetail.bank.accountNumberSuffix=accountNumberSuffix;
                  }
                }
             }


              //description
              earthportrequest.beneficiaryBankAccount.description = request.recipientDetail.bank.accountName;

              //countryCode
              if("countryCode" in request.recipientDetail.bank ){
                  earthportrequest.beneficiaryBankAccount.countryCode = getCountryCode(request.recipientDetail.bank.countryCode);
              }

              //currencyCode
              if("currencyCode" in  request.recipientDetail.bank){
                  earthportrequest.beneficiaryBankAccount.currencyCode = getCurrencyCode(request.recipientDetail.bank.currencyCode);
              }

              if("bankName" in request.recipientDetail.bank)
              {
                  earthportrequest.beneficiaryBankAccount.bankName = request.recipientDetail.bank.bankName;
              }

              if("accountName" in request.recipientDetail.bank)
              {
                  earthportrequest.beneficiaryBankAccount.accountName = request.recipientDetail.bank.accountName;
              }


              if('accountNumberType' in request.recipientDetail.bank){

                if(accountNumber[request.recipientDetail.bank.accountNumberType] === "iban"){
                    earthportrequest.beneficiaryBankAccount.iban = request.recipientDetail.bank.accountNumber;
                }

                if(accountNumber[request.recipientDetail.bank.accountNumberType] === "accountNumber"){
                    if("accountNumber" in request.recipientDetail.bank)
                    {
                        earthportrequest.beneficiaryBankAccount.accountNumber = request.recipientDetail.bank.accountNumber;
                    }
                }

              }

            
              if("accountType" in request.recipientDetail.bank)
              {
                if("countryCode" in request.recipientDetail.bank){
                  earthportrequest.beneficiaryBankAccount.accountType = getAccountType(getCountryCode(request.recipientDetail.bank.countryCode),request.recipientDetail.bank.accountType);
                }else{
                  earthportrequest.beneficiaryBankAccount.accountType = request.recipientDetail.bank.accountType;
                }
              }
            
              if("bankCodeType" in  request.recipientDetail.bank && 'bankCode' in request.recipientDetail.bank){            
                if((Object.keys(bankCode).indexOf(request.recipientDetail.bank.bankCodeType) > -1)){
                    earthportrequest.beneficiaryBankAccount[bankCode[request.recipientDetail.bank.bankCodeType]] = request.recipientDetail.bank.bankCode;
                }
             }else if('bankCode' in request.recipientDetail.bank){
                 earthportrequest.beneficiaryBankAccount[getBankCodeType(getCountryCode(request.recipientDetail.bank.countryCode),getCurrencyCode(request.recipientDetail.bank.currencyCode))]= request.recipientDetail.bank.bankCode;
              }
         


              if("branchCode" in request.recipientDetail.bank)
              {
                  earthportrequest.beneficiaryBankAccount.branchCode = request.recipientDetail.bank.branchCode;
              }

              if("accountNumberPrefix" in request.recipientDetail.bank)
              {
                  earthportrequest.beneficiaryBankAccount.accountNumberPrefix = request.recipientDetail.bank.accountNumberPrefix;
              } 

              if("accountNumberSuffix" in request.recipientDetail.bank)
              {
                  earthportrequest.beneficiaryBankAccount.accountNumberSuffix = request.recipientDetail.bank.accountNumberSuffix;
              } 



              if ('BIC' in request.recipientDetail.bank) {

                if("countryCode" in request.recipientDetail.bank){
  
                    if(Object.keys(swiftBic_Country).indexOf(getCountryCode(request.recipientDetail.bank.countryCode)) > -1 ){
                      earthportrequest.beneficiaryBankAccount.swiftBic = request.recipientDetail.bank.BIC;
                    }else{
                      earthportrequest.beneficiaryBankAccount.bic = request.recipientDetail.bank.BIC;
                    }
                }   
              } 
          }

    }
    //#endregion  
         

    earthportrequest=parse(JSON.stringify(earthportrequest));
    context.setVariable('private.earthportRequest', JSON.stringify(earthportrequest));
    context.setVariable('private.originalRequest', JSON.stringify(request));
    context.setVariable('private.source',"validate_EP_Request");

} catch(err) {  
     context.setVariable("triggerScriptError", true);
     context.setVariable("triggerScriptErrorMessage", err.message);
     throw err.message;
    }