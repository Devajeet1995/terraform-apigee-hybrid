try{
    
    var response = JSON.parse(context.getVariable('response.content').replace(/:\s*(\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d+)\s*([,\}])/g, ':"$1"$2'));
    var request = JSON.parse(context.getVariable('private.originalRequest'));
    var responseStatusCode = JSON.parse(context.getVariable('response.status.code'));
  
    if (responseStatusCode === 200) {
        var newresponse = {};
        if ('originatorDetail' in request) {
            if ('bankId' in request.originatorDetail || 'originatorId' in request.originatorDetail) {
                newresponse.originatorDetail = {};
            }
            if ('bankId' in request.originatorDetail) {
                newresponse.originatorDetail.bankId = request.originatorDetail.bankId;
            }
            if ('originatorId' in request.originatorDetail) {
                newresponse.originatorDetail.originatorId = request.originatorDetail.originatorId;
            }
        }
        if('serviceProviderDetail' in request)
        {
            if ('routingId' in request.serviceProviderDetail) {
                newresponse.serviceProviderDetail = {};
                newresponse.serviceProviderDetail.routingId = request.serviceProviderDetail.routingId;
            }        
        }
        if('transactionDetail' in request)
        {
            if ('retrievalReferenceNumber' in request.transactionDetail || 'systemTraceAuditNumber' in request.transactionDetail || 'payoutSpeed' in request.transactionDetail || 'expectedSettlementDate' in response) {
                newresponse.transactionDetail = {};
                if ('retrievalReferenceNumber' in request.transactionDetail) {
                    newresponse.transactionDetail.retrievalReferenceNumber = request.transactionDetail.retrievalReferenceNumber;
                }
                if ('systemTraceAuditNumber' in request.transactionDetail) {
                    newresponse.transactionDetail.systemTraceAuditNumber = request.transactionDetail.systemTraceAuditNumber;
                }
                if ('payoutSpeed' in request.transactionDetail) {
                    newresponse.transactionDetail.payoutSpeed = request.transactionDetail.payoutSpeed;
                }
                if ('expectedSettlementDate' in response) {
                    newresponse.transactionDetail.expectedPostingDate = response.expectedSettlementDate.split("/").reverse().join("-");
                }
            }
        }
    
        context.setVariable('response.content', JSON.stringify(newresponse));
            context.setVariable('private.source',"visaResponse");
    
    } 
} catch(err) {  
     context.setVariable("triggerScriptError", true);
     context.setVariable("triggerScriptErrorMessage", err.message);
     throw err.message;
    }