
//check JSON is valid or not
function isValidJSONString(str) {
    try {
        JSON.parse(str);
    } catch (err) {
         context.setVariable("triggerSchemaValidation", true);
         context.setVariable("triggerSchemaValidationMessage", err.message)
         throw err.message;  
        }
    return true;
}

messageContent = context.getVariable('message.content');
isValidJSONString(messageContent);